# Profil G2 candidat — qualification hors produit

Le candidat qualifie **l’observation et le chargement de données sûres** de
l’installation locale exacte `6.13.0-next`, avec refus reproductibles. Il ne clôt
pas G2 intégré et ne rend aucune nouvelle compétence lançable dans Madness.
Le cœur conserve l’autorité sur contrats, contexte, préconditions et reçus
(AD-2/3/7 de Winston). Ces propositions sont transmises à Sally 2.17 puis au
tracer 2.2 ; aucun contrat adopté n’est modifié.

## Résultat et limites

Trois modules (`core-tools`, `method`, `toolsmith`), 27 descripteurs de compétences,
trois aides de module réellement chargées, 43 topics référencés et deux migrations
référencées. Les 435 fichiers de skills représentent 2 715 799 octets. Aucun
problème natif `knowledge` ; le profil constate séparément que `method` déclare
`bmad-retrospective`, absent de l’installation. Diagnostic agrégé **partiel**,
capacités indépendantes : ce manque ne supprime pas les aides lisibles ni les
compétences présentes et ne déclenche aucune réparation. Voir
[inventory-local.json](inventory-local.json).

Les 17 entrées de l’epic sont retrouvées sans feuille ni `pull`. Le plan courant
porte sa propre preuve de statut. Le contexte BMad réel vient des couches de
configuration et du dossier actif `initiative-madness` effectivement observé.
Aucune sélection Madness persistée, conversation réattribuée ou session externe
reconstruite. Aucun compte, réseau fournisseur, agent, modèle ni installation.

Le run final [results.json](results.json) couvre M1–M15 sans skip, avec tests,
observations et appels séparés. Hardlinks NTFS, jonctions et remplacement d’un
ancêtre réellement exercés sous Windows 11 ; le remplacement refuse la lecture
avant consommation des octets, sur le chemin du handle réel. L’échec sandbox
antérieur reste conservé. Les 558 inputs verrouillés sont identiques avant/après
et toutes les fixtures possédées sont retirées. Le contrôle est local au banc,
pas une preuve native intégrée du produit ou d’une sandbox universelle.

## Capacités et états

| Capacité | Candidat et preuve |
|---|---|
| Diagnostic présence/format | M1–M3 : local exact, absent, marqueur ancien et preview inconnue distincts. L’ancien est seulement observé par son marqueur fixture, pas exploitable par un runtime prouvé. |
| Modules/skills | M3–M5 : inventaire sous garde ; métadonnées exclues des commandes ; SKILL.md, appartenance et prérequis manquants vérifiés séparément du script officiel. |
| Aides | M6/M11 : texte sûr effectivement chargé, absence/illisibilité explicite, aucune troncature silencieuse. |
| Topics/migrations/personas | M1/M6 : références descriptives, aucune migration ni activation. |
| Personnalisation | M7 : données fusionnées par chargeur officiel épinglé ; aucune permission d’exécution déduite. |
| Initiatives/contexte | M8/M9/M12 : observation et conflit explicite, output confiné, révision vérifiée. |
| Tickets sans feuille | M1/M13 : jointure officielle, plan/feuille/tracker et contradictions sourcés, acceptation inconnue. |
| Recommandation native `$bmad` | Non qualifiée ici. 2.2 doit transmettre les vraies aides et obtenir un reçu natif ; lire une aide n’est pas une réponse d’agent. |
| Exécution générale | Indisponible, M14. Une commande exacte copiable ne prouve runtime, permissions ou effets. Mary/Forge gardent leur profil déjà livré. |

Vocabulaire proposé : `absent`, `legacy-observed`, `unknown`, `partial`,
`candidate-observed`, `incompatible`, `invalidated`, `error`. Une preview non
testée est `unknown` ; une frontière refusée ou configuration illisible bloque
les capacités touchées avec code/source ; un record manquant rend l’inventaire
partiel. `candidate-observed` n’annonce aucune exécution générale. Le dernier
reçu reste historique lorsqu’invalidé ; l’état agrégé ne masque pas les capacités.

## Racines, sûreté et fraîcheur

Autorité du cœur : racine canonique du projet ouvert et racines de skills
réellement actives de l’hôte explicitement autorisées, dans l’ordre officiel,
projet avant utilisateur. Aucun home réel exploré par ce spike. Le premier **nom
de dossier** masque ses homonymes en entier, même sans `bmod.toml` ; une copie
utilisateur masquée ne réapparaît pas pour réparer un manque (M4).

Préflight : toute composante reparse/symlink et tout hardlink de fichier refusés,
type régulier, chemin réel du handle Windows, identité des ancêtres et du fichier
contrôlés avant lecture puis après. UTF-8 strict. Bornes expérimentales : 1 Mio
par fichier, 16 Mio par corpus, 1 024 entrées fichiers+dossiers, profondeur 12.
Elles s’appliquent aussi aux manifestes/configurations non bornés par les scripts
officiels. Un dépassement invalide la collecte concernée sans tronquer une aide
ou annoncer un catalogue complet. Ce ne sont ni limites officielles BMad ni
décisions de pagination UI.

Les octets admis sont copiés dans un snapshot privé après contrôle de révision.
Les fonctions gérées travaillent sur ce snapshot, nouveau préflight dans le
worker, et ne chargent aucun module du projet analysé. Le texte d’aide n’exécute
pas ses instructions. `setup --status`, `render_skill`, hooks, migrations,
installation, agent et modèle ne servent pas de sonde. La fusion est appelée
directement pour éviter le hook `setup_check.report` de la CLI de personnalisation.
`tickets.central_config` peut importer le script du projet : voie exclue sur
projet non fiable, sans prétendre la CLI native sûre dans ce cas.

La révision inclut noms, identités de chemins et SHA-256 des octets. Contenu
modifié, ajout, disparition et remplacement invalident le reçu (M12). Avant une
opération, le cœur recapture les sources pertinentes et exige même révision et
contexte. Pas de durée arbitraire ni fraîcheur fondée seulement sur l’horloge.
La fraîcheur vaut au point de contrôle ; l’intégration doit reprendre la garde
au point d’effet, sans promettre un système de fichiers immuable.

BMad peut résoudre un output externe ; ce comportement n’élargit pas Madness.
Relatif, absolu interne et `{project-root}` interne sont admis ; traversal, URI,
chemin relatif à lecteur et sortie externe refusés. Initiative active absente
reste absente ; plusieurs initiatives ne conduisent pas à un choix implicite.
Une extension aux chemins externes exigerait son propre contrat qualifié.

## Personnalisation constatée

Centrale : `_bmad/config.toml`, `_bmad/custom/config.toml`, puis
`_bmad/custom/config.user.toml`. `_bmad/config.user.toml` historique est ignoré.
Compétence : son `customize.toml`, `_bmad/custom/<skill>.toml`, puis
`<skill>.user.toml`. Tables récursives ; tableaux ordinaires ajoutés ; tableaux
de tables à `code`/`id` remplacent **l’élément complet**, anciens champs retirés.
Un TOML présent invalide produit une erreur, sans repli silencieux. Les racines
sont explicites. Les commentaires « quatre couches » ne changent pas le code.

## Contrats documentaires proposés au cœur

`EvidenceRef` : identifiant de source, racine autorisée, chemin relatif,
SHA-256, révision de collecte, date d’observation, origine projet/utilisateur/géré,
portée et fraîcheur courante/invalidée/historique. Les préfixes de snapshots du
banc sont reliés aux sources réelles dans [sources.md](sources.md), pas offerts
comme actions d’ouverture après suppression.

`ProfileDiagnostic` : identité/version exacte du profil et runtime, racines
ordonnées, révision, état agrégé et capacités indépendantes avec disponibilité,
codes de raison, preuves et récupération proposée. Une capacité manquante
explique sa condition ; aucun setup implicite. Diagnostic périmé conservé comme
historique, lecture ciblée requise avant effet.

`KnowledgeBundle` : module/record, skills couvertes, documents avec texte
effectivement chargé et preuve, topics/migrations avec référence seule, problèmes
et couverture limitée à la portée lue. `AgentRecommendation` est distinct :
conversation/tour natifs, bundle réellement transmis et empreintes, réponse brute
reçue, raisons et alternatives proposées par l’agent. Sans reçu, afficher les
aides sans « BMad recommande ». Aucun ordre de workflow obligatoire fabriqué.

`ActionDescriptor` : identité de compétence/module, invocation Codex exacte
`$<nom-dossier>` pour les descripteurs observés, objectif, entrées, conditions,
effets/livrables et preuves. Champs absents inconnus ; le nom de fichier n’invente
pas un objectif. `copyable` indépendant de `launchability`. SKILL, appartenance
ou prérequis non prouvé rend l’action descriptive avec refus expliqué. Le
catalogue conserve outils transversaux et modules, sans quota métier fixe.

`CapturedBmadContext` : projet/racine canonique, profil/révision, output confiné,
initiative BMad résolue/absente, sélection locale Madness séparée, conflits et
preuves. Une action sans initiative reste possible selon ses conditions ; celle
qui l’exige est bloquée en conflit jusqu’à résolution explicite. La navigation
ne modifie jamais le contexte capturé d’une conversation ou opération passée.

`InvocationReceipt` : identifiant d’opération, contexte capturé, descripteur et
révisions vérifiés avant envoi, texte exact transmis, connecteur/connexion et
capacités, accusé natif, résultat connu/inconnu/échec. Copier ne signifie pas
envoyer ; accusé ne signifie ni fin de workflow ni accord humain. Aucune union
d’invocation produit étendue ici.

`TicketEvidence` : conteneur/id, preuve TOML, feuille optionnelle avec ses propres
champs, plan optionnel et `ticket`/statut, tracker éventuel, contradictions/drift,
état dérivé avec preuves séparées. Octets/empreintes du plan et de la feuille
restent sourcés ; le chargeur officiel possède la jointure, sans création de
feuille. `built` ou fichier présent ne devient pas acceptation humaine ; celle-ci
exige une décision rattachée à l’objet et à sa révision.

Ces propositions n’ajoutent aucune mesure : R32/Q8/Q9 restent dans leurs stories.
Aucune bascule SIWC, facturation, cache réseau ou sélection persistante déduite.

## Transmission et inconnus

Sally 2.17 : distinguer diagnostic partiel, action descriptive/copiable/lançable,
aide chargée/réponse native, initiative active/sélection locale, statut/accord
humain. Conserver projet, conversation et brouillon pendant relecture/refus.
Provenance et récupération à la demande sans perdre le chemin principal ; les
contrats visuels et palette adoptés demeurent l’autorité.

Tracer 2.2 : qualifier réellement `$bmad`, transmettre le bundle chargé,
obtenir le reçu natif, conserver réponse/alternatives et contrôler révisions
avant envoi selon AD-2/3/7. Découvrir une compétence ne suffit pas à l’envoyer
dans le moteur. Clôture 2.16 : vérifier les consommateurs intégrés, les gardes
avant opérations et la version installée ; ce banc ne prouve ni catalogue UI,
ni dialogue général, ni G2 intégré.

Autres versions/OS, racines hôte non observées, compatibilité de dépendances
complexes, hooks tiers et initialisation restent non qualifiés. Le manque
`bmad-retrospective` est un fait à représenter, pas une obligation d’installation.
L’audit Python contrôle ces fonctions connues, pas du code arbitraire. Mutations
au point d’effet futur et adversaire OS possédant le compte restent à traiter à
l’intégration. Aucun accord visuel humain ou capacité produit acquis.

## Reproduction

Depuis la racine du dépôt, runtime existant :

```powershell
& 'C:\Users\UP60066553\scoop\apps\uv\current\uv.exe' run --offline --no-project --no-cache --python 'C:\Sources\madness\.venv\Scripts\python.exe' python -B 'C:\Sources\madness\_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\scenarios.py'
& '.venv\Scripts\python.exe' -B '_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\verify.py'
```

Les liens Windows exigent les droits réels : WinError5 sandbox ne vaut pas test
vert. Le final a été autorisé hors sandbox pour ces fixtures seulement. Le
vérificateur est en lecture seule ; `--seal` est une étape explicite après
inspection des artefacts et ne rafraîchit pas le verrou des sources. Aucun setup,
réseau, OAuth, modèle, installation ou produit n’est nécessaire.
