# Sources du candidat G2 — 28 octobre 2026

Sources exclusivement locales. Les SHA-256 exacts, les deux exécutables CPython,
les six paires de scripts identiques et les 558 entrées de conservation figurent
dans [sources-lock.json](sources-lock.json). Aucun code d’un projet analysé
n’est importé comme programme. Les versions ne remplacent pas les empreintes.

| Source primaire locale | Usage et limite |
|---|---|
| `_bmad/scripts/knowledge.py`, copie `.agents/skills/bmad/scripts/knowledge.py` | `collect` et `scan` réellement appelés. Premier dossier homonyme gagnant même sans record ; modules, skills, aides, topics et migrations distincts. Ne prouve ni SKILL.md ni runtime. |
| `_bmad/scripts/config_utils.py`, même copie gérée | `load_central_config` et `load_customization` réellement appelés. Trois couches réelles dans chaque cas ; éléments à code/id remplacés en entier. Aucun parseur parallèle présenté officiel. |
| `_bmad/scripts/roster.py`, même copie gérée | `collect` réellement appelé sur snapshot avec racine explicite. Personas déclaratives, aucune activation d’agent. |
| `_bmad/scripts/resolve_config.py`, `resolve_customization.py`, copies identiques | Sources inspectées/épinglées. Fonctions de fusion appelées directement. Le commentaire « four layers » ne correspond pas aux trois couches effectivement chargées. |
| `_bmad/scripts/setup_check.py`, copie identique | Source inspectée/épinglée seulement. Aucun appel de ce hook ni de setup. |
| `.agents/skills/bmad-agent-po/scripts/tickets.py` | `load_folder` réellement appelé sans feuille créée. `central_config` peut importer le script du projet : voie exclue. Aucune fonction de mutation, `pull`, `mark`, `mirror` ou `move`. |
| `.agents/skills/bmod-{core-tools,method,toolsmith}/bmod.toml` | Trois déclarations exactes `6.13.0-next`. Inventaire dans [inventory-local.json](inventory-local.json), aucune plage universelle v7. |
| `.agents/skills/bmad/SKILL.md`, `references/help.md`, aides des trois records | Sources du futur `$bmad` et de ses aides. Instructions de skill non exécutées pendant ce spike. |
| `_bmad/config.toml`, `_bmad/custom/*.toml` | Données projet lues strictement, copiées puis résolues par chargeur épinglé. Aucune configuration globale ni donnée de compte lue. |
| `epic-projets-bmad/tickets/` | 17 entrées TOML sans feuille et plan courant, aucun ticket matérialisé. Statut de plan distinct de l’accord humain. |
| Produit/contrats/tests nommés dans le plan | Limite Mary/Forge et autorité du cœur conservées. Aucun changement ni suite produit utilisée comme preuve G2. |

Le périmètre fermé de conservation comprend tous les fichiers de `src/`,
`tests/`, `resources/`, `_bmad/scripts/`, `.agents/skills/`, les TOML observés sous
`_bmad/custom/`, `_bmad/config.toml`, `skills-lock.json`, les manifestes de
dépendances et configurations TypeScript/Vite reconnues par le verrou. La liste
complète est le verrou ; le vérificateur recherche aussi les ajouts/suppressions
dans ces mêmes périmètres. Aucun coffre, profil installé, AppData ou connexion.

Les seules racines réelles collectées comme corpus sont l’installation de skills
du dépôt et le répertoire des entrées de cet epic. Le contexte actif est lu dans
la configuration et les fichiers d’initiative immédiats de l’output du dépôt.
Racines utilisateur, collisions, formats anciens/futurs et attaques sont des
fixtures synthétiques. Aucune racine utilisateur réelle n’est dite couverte sans
configuration hôte observée.

Le worker charge les octets épinglés des modules nommés dans un `sys.modules`
contrôlé ; jamais les scripts d’une fixture. CPython 3.12.14 existant, `-I -B`,
JSON stdin, délai 15 s et plafond 4 Mio par flux. `uv 0.13.0` sert de lanceur
offline, interpréteur existant explicite, sans installation ni paquet résolu.

Les chemins des retours officiels sont ceux des snapshots jetables, utiles pour
vérifier priorité et références pendant l’essai. Ils ne sont pas des liens UI
vers un chemin supprimé. Pour le réel, le préfixe `snapshots/real-skills/`
correspond à `.agents/skills/` dans ce dépôt ; `source_revision`, inventaire et
verrou relient cette observation aux sources persistantes. Les commandes, tailles,
durées, refus et résultats figurent dans [calls.log](calls.log),
[results.json](results.json) et [scenarios.log](scenarios.log).

L’échec du cache uv et le refus de liens du run sandbox sont conservés dans
[instrumentation.log](instrumentation.log), [attempt-sandbox.log](attempt-sandbox.log)
et son JSON. Le final hors sandbox ne touche que les fixtures possédées pour les
liens NTFS ; les fonctions gérées restent instrumentées, sans réseau ni moteur.
