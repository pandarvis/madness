"""Closed evidence verifier; no product/test suite, no account or AppData reads."""
import hashlib
import json
from pathlib import Path
import sys
import fixtures
import prototype as p

REQUIRED = ['prototype.py', 'scenarios.py', 'fixtures.py', 'verify.py', 'sources-lock.json',
            'results.json', 'inventory-local.json', 'scenarios.log', 'calls.log', 'profil-g2.md',
            'sources.md', 'instrumentation.log', 'attempt-sandbox-results.json', 'attempt-sandbox.log']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    checks = []
    def check(label, condition):
        checks.append({'check': label, 'passed': bool(condition)})
        if not condition:
            raise AssertionError(label)
    lock = p.check_lock()
    for name in REQUIRED:
        check('artifact ' + name, (p.HERE / name).is_file())
    results = json.loads((p.HERE / 'results.json').read_text(encoding='utf-8'))
    check('15 tests passed without skips', results['tests'] == {'run':15, 'passed':15, 'failures':0, 'errors':0, 'skipped':0})
    check('matrix M1-M15 unique and complete', {m['id'] for m in results['matrix']} == {'M'+str(i) for i in range(1,16)} and len(results['matrix']) == 15)
    check('every matrix row has a passed assertion', all(m['passed'] and m['assertions'] > 0 for m in results['matrix']))
    log = (p.HERE / 'scenarios.log').read_text(encoding='utf-8')
    for i in range(1,16):
        check('logged executed M'+str(i), any(line.startswith('test_M'+str(i)+'_') and line.endswith(' ... ok') for line in log.splitlines()))
    check('observations distinct from tests', {o['case'] for o in results['observations']} == {'M'+str(i) for i in range(1,16)})
    check('actual Windows NTFS test executed', results['platform'].startswith('Windows-') and any(o['case']=='M10' and o['data']['ancestor']=='HANDLE_REDIRECTED' for o in results['observations']))
    check('all fixture teardown receipts', len(results['cleanup'])==15 and all(x['removed'] for x in results['cleanup']))
    check('no disposable fixture remains', not list(p.HERE.glob('fixtures-run-*')))
    check('preservation read before/after identical', results['preservation']['unchanged'] and results['preservation']['before']==results['preservation']['after']==lock['preservation_before'])
    check('current product/managed/config inputs identical', fixtures.preservation()==lock['preservation_before'])
    check('paired managed scripts identical', all(c['identical'] and digest(Path(c['source']))==digest(Path(c['copy']))==c['sha256'] for c in lock['copies']))
    check('no ordinary managed call attempted an effect', all(not c['denied_effects'] for c in results['calls'] if c['op']!='audit-probe'))
    check('intentional socket/write audit probe denied', any(set(c['denied_effects'])=={'socket.__new__','write'} for c in results['calls'] if c['op']=='audit-probe'))
    calls = [json.loads(line) for line in (p.HERE / 'calls.log').read_text(encoding='utf-8').splitlines() if line]
    check('calls bounded in size/time', len(calls)>=len(results['calls']) and all(c['stdout_bytes']<=p.OUTPUT_LIMIT and c['stderr_bytes']<=p.OUTPUT_LIMIT and c['duration_ms']<p.TIME_LIMIT*1000 for c in calls))
    inventory = json.loads((p.HERE / 'inventory-local.json').read_text(encoding='utf-8'))
    check('exact three local preview modules', len(inventory['modules'])==3 and {m['table']['version'] for m in inventory['modules']}=={'6.13.0-next'})
    check('partial inventory not promoted', inventory['profile']=='partial' and all(s['launch']=='unqualified' for s in inventory['skills']))
    check('17 entries without leaves', len(inventory['tickets'])==17 and all(t['file'] is None for t in inventory['tickets']))
    manifest = p.HERE / 'evidence-manifest.json'
    hashes = {name:digest(p.HERE/name) for name in REQUIRED}
    if sys.argv[1:] == ['--seal']:
        manifest.write_text(json.dumps({'schema':1, 'sha256':hashes}, indent=2), encoding='utf-8')
    elif sys.argv[1:]:
        raise AssertionError('only --seal or no arguments')
    check('evidence sealed and unchanged', manifest.is_file() and json.loads(manifest.read_text(encoding='utf-8'))['sha256']==hashes)
    summary = {'checks':len(checks), 'passed':len(checks), 'failed':0, 'matrix_rows':15,
               'assertions':sum(m['assertions'] for m in results['matrix']), 'observations':len(results['observations']),
               'preserved_inputs':len(lock['preservation_before']), 'manifest_sha256':digest(manifest)}
    print(json.dumps(summary, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
