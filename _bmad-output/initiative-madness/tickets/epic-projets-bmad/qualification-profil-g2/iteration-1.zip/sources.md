# Sources de la reprise1 G2 — 28 octobre 2026

Le [verrou explicite](sources-lock.json) conserve les sept scripts gérés,
six copies identiques, uv0.13.0, les734fichiers du runtime effectif CPython3.12.14
et le périmètre produit/géré/configuration. Les fonctions exploitées restent
`knowledge.collect/scan`, `config_utils.load_central_config/load_customization`,
`roster.collect`, `tickets.load_folder` et `tickets.parse_frontmatter`. Les
résolveurs et setup_check sont seulement épinglés/inspectés, jamais invoqués.
Les scripts du projet analysé et les hooks ne sont jamais importés.

Le modèle de runtime reprend `src/adapters/bmad/runtime.ts` et `profile.ts` :
base hors projet, empreinte `0f3ef35995160c8db3b4892d9bb3bd9ea0eba75634d4fc4505eef13e7ce56f92`
sur python.exe, python3.dll, python312.dll, vcruntime140.dll,
vcruntime140_1.dll, DLLs et Lib, récursion et extensions identiques ; dossiers
site-packages/__pycache__/test/tests exclus de l’empreinte du produit.
Le lanceur PowerShell contrôle cet arbre avant le premier Python, refuse
pyvenv.cfg et python*._pth à la base, puis lance via uv offline/no-project/
no-config/no-cache. Entrée et workers utilisent la base avec `-I -S -B` et un
environnement filtré. M15 observe flags/prefix/sys.path et éprouve stdlib,
DLL, .pth et home/venv sur de seules copies possédées, sans exécuter les copies.
L’audit n’est pas une sandbox universelle contre du code arbitraire.

Complément de démarrage UV, ajouté explicitement au verrou après les deux
premiers runs reprise1 conservés intacts : uv0.13.0 inspecte l’interpréteur avec
`-I -B`, **sans** `-S`, pour obtenir le sys.path initialisé par site. C’est une
preuve statique du [code amont versionné](https://raw.githubusercontent.com/astral-sh/uv/0.13.0/crates/uv-python-interpreter/src/interpreter.rs)
(query, lignes1172–1191), distincte des mesures locales. Le programme Python de
requête est aussi lisible dans le binaire uv épinglé et importe `site`.

La base réelle possède un seul `.pth`, `Lib/site-packages/distutils-precedence.pth`,
151octets, SHA256`2638ce9e2500e572a5e0de7faed6661eb569d1b696fcba07b0dd223da5f5d224`.
Ses octets sont conservés dans `sources-lock.json/startup`. Il importe `os`
(stdlib épinglée), teste `SETUPTOOLS_USE_DISTUTILS` contre `local`, puis utilise
le court-circuit `enabled and __import__('_distutils_hack').add_shim()`.
`stdlib` est imposé dans le **seul** environnement enfant, avant toute inspection
uv : l’import conditionnel n’appartient donc pas à la voie retenue. La liste
des `.pth` doit être exactement cette entrée ; nouveau `.pth`, contenu modifié,
sitecustomize*/usercustomize* à la base ou dans site-packages, python*._pth et
python312.zip à la base sont refusés avant lancement. Liens/hardlinks du hook
exploité sont refusés. Aucun hook réel, paquet ni runtime n’est modifié.

M15 combine trois preuves explicitement distinctes : garde et contenu exacts
du hook, simulation contrôlée de son branchement dans le harnais de confiance,
et appel uv réel sur une copie exacte du runtime + hook réel épinglé avec
environnement neutralisé. Le programme d’observation du harnais constate
l’environnement et les flags du processus final. Les flags **internes** de
l’inspection uv reposent sur la source versionnée, sans instrumentation OS
locale prétendue. Les hooks de fixtures modifiés sont seulement des
contre-exemples de refus avant lancement : aucun nouveau `.pth`, module helper
ou sitecustomize de fixture n’est exécuté. Les probes opèrent sans réseau,
sans bytecode et sont nettoyés avec les fixtures.

La collecte de skills est bornée avant les fonctions gérées et répétée dans
le worker. La relation module→skill est aussi vérifiée contre le record
skill→module ; les deux sources de contradiction restent visibles. Les
personnalisations réellement exploitées par roster sont prévalidées afin
d’interdire le repli silencieux de `agent_identity` après ConfigError.

Le contexte a une collecte `context-v1` distincte : trois couches centrales
possibles et seuls fichiers `<initiative>/<initiative>.md` immédiats exploités,
noms/identités/empreintes/octets, limite cumulée16Mio,1024entrées et1Mio/fichier.
Aucun scan récursif de l’output binaire. Sa révision est recapturée avant usage,
indépendamment de celle des skills ; M8 modifie seulement une initiative et
M11 dépasse réellement le plafond avec17fichiers de1Mio.

Les preuves de tickets sont capturées **avant** la jointure officielle : entrée
TOML, feuille, plan et champs tracker ont leurs sources/champs/empreintes propres.
Les contenus complets sont sérialisés dans chaque run, dont
`tickets-local.json` et `tickets-conflict.json`, après retrait des snapshots.
La projection jointe n’efface aucune preuve, et n’est pas un accord humain.

Chaque `run.ps1 -Action run` crée `runs/run-<UUID>/`. Aucun run ni sceau existant
n’est réécrit. `seal` crée son manifeste une fois, `verify` lit sans mettre à jour,
et `promote` écrit un reçu explicite plus le seul pointeur `selected-run.json`.
Les fichiers de code/pins exécutés sont copiés dans le run. Le premier banc,
ses erreurs et les revues demeurent dans [iteration-0.zip](iteration-0.zip) et
[rederivation.md](rederivation.md). Les erreurs de bootstrap de cette reprise
sont décrites dans [instrumentation.log](instrumentation.log).

Les chemins officiels dans l’inventaire désignent les snapshots jetables de
l’essai, jamais des commandes UI d’ouverture après nettoyage. Pour le local,
`snapshots/real-skills/` correspond à `.agents/skills/` du dépôt ; révision,
sources-lock et empreintes persistantes fournissent le rapprochement.
Racines utilisateur, versions anciennes/futures et attaques sont des fixtures.
Le périmètre de conservation couvre src/tests/resources, scripts gérés,
.agents/skills, configurations observées, dépendances et fichiers de build
énumérés dans le verrou ; ajouts/suppressions sont également détectés.
Aucun coffre, AppData personnel, réseau, modèle ni installation n’est lu/requis.
