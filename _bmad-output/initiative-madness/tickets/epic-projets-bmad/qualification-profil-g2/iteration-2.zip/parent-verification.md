# Vérification parent — story2.1

30octobre2026. Baseline : `ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb`.
Qualification isolée du profil BMad local, sans modification du produit.

## Résultats vérifiés

- Run courant : `run-517afc048ef54c29806faaf1e4540feb`,15/15tests,230assertions,
  21observations,23appels gérés, zéro skip ; durée446,276s.
- M1–M15 ont chacun des assertions passées. Les frontières M10 utilisent de
  vrais hardlinks/jonctions Windows et le remplacement d'un ancêtre avant lecture.
- M8/M12 résolvent les mêmes octets que le reçu ; alpha devenu beta invalide
  l'ancienne résolution sans changer les skills. M7 refuse le TOML de roster
  malformé avant son repli d'identité. M13 conserve séparément les sources
  TOML/feuille/plan/tracker avant la jointure officielle.
- M15 : copie fermée734fichiers avant premier UV, deux gardes,14variantes non
  admises refusées sans lancer leur Python/hook. Le probe UV positif utilise
  seulement la copie exacte. Le scope d'audit Python est explicite ; aucune
  sandbox OS universelle n'est prétendue.
- 558inputs produit/gérés/configurations identiques avant/après ;129entrées
  sources contrôlées indépendamment. Aucun compte, AppData, moteur ou paquet
  personnel requis ; aucun appel réseau/fournisseur programmé par le banc.
- Scellement et promotion explicites73/73 chacun ; vérification en lecture seule72/72 et18fichiers du reçu identiques avant/après. SHA256 du manifeste :
  `19e6c9a7888c82c4428e4790307dfdfddd46ab9686dec14f55ea88e1bbf2fdb2`.
- 80fichiers des cinq reçus historiques et deux archives identiques. Les reçus
  ciblés ou échoués sont conservés, non scellés et non qualifiés globalement.
- Bloc approuvé SHA256 :
  `04d5977b155af629da97dddb2fdfd6fcd85688948de133cc701c6d389037db18`.
  Attributs Git `-text` pour préserver les octets des preuves et du seul plan.

## Échecs et correction de reprise

Les essais initiaux et les deux re-dérivations restent consultables dans les
archives, revues et runs. Le30octobre, les ciblés0979… passent3/3à15s/appel,
mais le complet77868… reste13/15 : délais dépassés dans la garde native M15 et
knowledge M1. M10 et les autres cas passent ;558inputs et nettoyage conservés.
Seul délai du banc porté à60s/appel, sorties4Mio et lanceur600s inchangés.
Le nouveau run complet mesure19,360s pour knowledge et18,250s pour roster.
Aucun retry ni refus de fichier assoupli. Ce budget expérimental ne définit
pas une latence UI, une durée par US ou un timeout métier.

## Reproduire les contrôles

Depuis la racine, PowerShell7 :

```powershell
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action run
# Un nouveau run, puis scellement explicite, jamais rafraîchissement d'un ancien.
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action verify -RunId 'run-517afc048ef54c29806faaf1e4540feb'
node '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/parent-verifier.mjs'
```

Le profil dépend de ces sources et runtimes exacts. Les liens NTFS doivent être
réellement autorisés : un refus est un échec, jamais un skip vert. Le vérificateur
parent est en lecture seule ; son résultat courant est dans
[parent-verification.json](parent-verification.json). Le contrôle du reçu avant
et après la vérification Python est dans
[readonly-verification.json](readonly-verification.json). L'absence de fixtures
est vérifiée après la fin des lanceurs, sans toucher à un profil personnel.

## Revues et portée

Revue Quick et audit indépendant des frontières encore à rendre à ce point.
Le plan conserve les constats des deux tours précédents et leurs routes.

Installation exacte :6.13.0-next, trois modules,27descripteurs, trois aides
chargées,43topics et deux migrations en références. Diagnostic partiel connu :
bmad-retrospective absente, sans réparation implicite. Contrats proposés au cœur
pour Sally2.17 puis tracer2.2 ; G2 intégré reste à vérifier en2.16. Mary/Forge,
SIWC, cache réseau et l'application installée sont inchangés. Suite produit,
build et installateur non relancés car leurs sources sont conservées. Aucune
acceptation visuelle humaine ni clôture des autres epics déduite.