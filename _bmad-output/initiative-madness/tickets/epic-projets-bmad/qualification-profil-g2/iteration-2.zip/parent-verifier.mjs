import {readFile,readdir,lstat} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {join} from 'node:path'
const root='_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2'
const hash=b=>createHash('sha256').update(b).digest('hex')
const read=p=>readFile(p,'utf8').then(v=>JSON.parse(v.replace(/^\uFEFF/,'')))
const ok=(value,label)=>{if(!value)throw new Error(label)}
const code=['prototype.py','fixtures.py','scenarios.py','runtime_guard.py','evidence.py','verify.py','run.ps1','runtime-preflight.ps1','preflight-probe.ps1','sources-lock.json']
const dataNames=['results.json','inventory-local.json','context-local.json','tickets-local.json','tickets-conflict.json','scenarios.log','calls.log']
const lock=await read(join(root,'sources-lock.json'))
const selected=await read(join(root,'selected-run.json'))
ok(lock.schema===2&&lock.runtime.policy==='closed-copy-v2','Current closed runtime policy')
const runs=[]
for(const item of await readdir(join(root,'runs'),{withFileTypes:true})){
 ok(item.isDirectory()&&/^run-[a-f0-9]{32}$/.test(item.name),'Unexpected run path')
 const dir=join(root,'runs',item.name),entries=await readdir(dir),hashes={}
 for(const name of entries){
  const path=join(dir,name),info=await lstat(path)
  ok(info.isFile()&&!info.isSymbolicLink()&&info.nlink===1,'Non-regular evidence '+path)
  hashes[name]=hash(await readFile(path))
 }
 const data=await read(join(dir,'results.json'))
 const runLock=await read(join(dir,'sources-lock.json'))
 const historical=(runLock.schema??1)<2
 const full=data.tests.run===15&&data.tests.passed===15&&data.tests.failures===0&&data.tests.errors===0&&data.tests.skipped===0
 const sealed=entries.includes('evidence-manifest.json')
 const before=data.preservation.before,after=data.preservation.after
 ok(Object.keys(before).length===558&&Object.keys(after).length===558,'Input closure '+item.name)
 ok(Object.entries(before).every(([p,h])=>h===after[p]&&h===lock.preservation_before[p]),'Preservation '+item.name)
 ok(data.cleanup.length===data.tests.run&&data.cleanup.every(c=>c.removed),'Cleanup '+item.name)
 if(sealed){
  const manifest=await read(join(dir,'evidence-manifest.json'))
  const expected=[...code.filter(n=>!historical||!['runtime-preflight.ps1','preflight-probe.ps1'].includes(n)),...dataNames].sort()
  ok(JSON.stringify(Object.keys(manifest.sha256).sort())===JSON.stringify(expected),'Closed manifest '+item.name)
  ok(Object.entries(manifest.sha256).every(([n,h])=>hashes[n]===h),'Payload hashes '+item.name)
  ok(full&&data.matrix.length===15&&data.matrix.every((m,i)=>m.id==='M'+(i+1)&&m.passed&&m.assertions>0),'Passed complete matrix '+item.name)
 }
 if(item.name===selected.run){
  ok(!historical&&sealed&&full,'Selection is a current qualified run')
  ok(selected.manifest_sha256===hashes['evidence-manifest.json'],'Selected manifest')
  for(const name of code)ok(hash(await readFile(join(root,name)))===hashes[name],'Selected executed code '+name)
 }
 runs.push({run:item.name,historical,sealed,full,tests:data.tests,assertions:data.matrix.reduce((n,m)=>n+m.assertions,0),observations:data.observations.length,hashes})
}
ok(runs.some(r=>r.run===selected.run),'Selection exists')
const before=await read(join(root,'reproduction-v2-before.json'))
for(const [relative,expected] of Object.entries(before))ok(hash(await readFile(join(root,...relative.split(/[/\\]/))))===expected,'Changed historical receipt '+relative)
ok(Object.keys(before).length===80,'Historical closure')
for(const [name,expected] of [['iteration-0.zip','109c937e26b8dd2e3b3dfedf0b0abdae814be089ac36a486f8553cda53b223be'],['iteration-1.zip','dd86933f293a98587dc6585d11b46c76029eb283a40727bdc8a94a5779bb31a2']])ok(hash(await readFile(join(root,name)))===expected,'Archive changed '+name)
ok(!(await readdir(root)).some(n=>n.startsWith('fixtures-')),'Owned transient remains')
const inputProof=await read(join(root,'parent-inputs.json'))
const sourceChecks=[]
for(const item of inputProof.inputs){
 let current=null
 try{current=hash(await readFile(item.path))}catch(error){if(error.code!=='ENOENT')throw error}
 ok(current===item.sha256,'Source changed '+item.path)
 sourceChecks.push({...item,current})
}
ok(sourceChecks.length===129&&inputProof.baseline==='ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb','Independent input closure')
const plan=await readFile(join(root,'../tickets/spike-qualifier-le-profil-bmad-existant-et-les-contrats-de-guidage-plan.md'),'utf8')
const frozenSha256=hash(plan.match(/<frozen-after-approval[\s\S]*?<\/frozen-after-approval>/)[0])
ok(frozenSha256==='04d5977b155af629da97dddb2fdfd6fcd85688948de133cc701c6d389037db18','Approved intent changed')
const result={status:'passed',baseline:inputProof.baseline,inputCount:sourceChecks.length,frozenSha256,selected,historicalFilesUnchanged:80,archivesUnchanged:2,runCount:runs.length,runs}

console.log(JSON.stringify({...result,runs:runs.map(({hashes,...rest})=>rest)}))
