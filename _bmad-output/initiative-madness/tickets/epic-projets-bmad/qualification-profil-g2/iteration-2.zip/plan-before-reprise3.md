---
title: 'Qualifier le profil BMad existant et les contrats de guidage'
type: 'chore'
ticket: '1'
created: '2026-10-28'
status: 'in-review'
baseline_revision: 'ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb'
route: 'full'
route_source: 'auto'
risk: 'high'
review: 'quick'
review_source: 'pinned'
lenses_ran: ['quick']
review_loop_iteration: 3
context:
  - '{project-root}/AGENTS.md'
  - '{project-root}/_bmad-output/initiative-madness/tickets/epic-projets-bmad/epic-projets-bmad.md'
  - '{project-root}/_bmad-output/initiative-madness/architecture-madness/architecture-madness.md'
  - '{project-root}/_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/rederivation.md'
  - '{project-root}/_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/rederivation-2.md'
---

<frozen-after-approval reason="human-owned intent — do not modify unless human renegotiates">

## Intent

**Problem:** Madness sait exécuter deux profils épinglés, Mary et Forge, mais ne qualifie pas encore les projets BMad ouverts, leurs aides, compétences, initiatives et tickets. Leur seule présence ou la mention v7 ne permet pas de promettre un guidage exécutable.

**Approach:** Qualifier hors produit un profil candidat G2, sur l’installation locale et des fixtures représentatives, avec un banc reproductible en lecture seule. Consigner capacités, refus et contrats de contexte/aide/invocation dans `qualification-profil-g2/profil-g2.md`, pour Sally2.17 puis le tracer2.2. Risque élevé : une découverte trop permissive pourrait lire hors portée ou transformer des fichiers non fiables en commandes.

## Boundaries & Constraints

**Always:** Sources et limites exactes ; chemins canoniques et racines explicitement autorisées, priorité conservée ; lecteurs bornés, UTF-8 strict, refus de liens/reparse points/hardlinks sur les chemins exploités ; empreinte/révision et contrôle de changement avant action. Profil par capacités indépendantes, états diagnostic sourcés et inconnus conservés. Outils de provenance maîtrisée seulement, scripts et runtime épinglés ; aucun code fourni par une fixture ou un projet ouvert n’est exécuté. Tests Windows réels des frontières et traces expurgées. Une commande copiable n’est pas une capacité lançable. Aucun accord humain ni statut inventé.

**Never:** Modifier `src/`, tests produit, dépendances, scripts gérés BMad, configuration personnelle, installation ou coffre ; réseau, OAuth, fournisseur ou modèle ; exécuter `setup --status` (il consulte GitHub), migrations, hooks, ou `render_skill` comme simple sonde. Aucun G2 intégré clos, catalogue/aide native livrés, nouvelle UI, persistance de sélection ou initialisation de projet dans ce spike. Aucun cache réseau intégré implicitement ni nouvelle dépendance d’epic. Aucune limite éditoriale en tokens.

## I/O & Edge-Case Matrix

| Scénario | Entrée / état | Résultat attendu | Erreur / limite |
|---|---|---|---|
| M1 | Installation locale exacte `6.13.0-next` | Inventaire sourcé modules, compétences, aides, personnalisation, contexte et tickets sans feuille ; empreintes avant/après identiques | Capacités intégrées non prouvées restent indisponibles |
| M2 | Projet sans BMad ; structure ancienne reconnue ; version future/inconnue | Absence, ancien observé et inconnu distingués avec raisons | Aucun lancement supposé compatible |
| M3 | Manifestes manquants, TOML invalide, dépendance/appartenance incohérente, SKILL absent | Partiel ou incompatible selon preuve ; capacités touchées bloquées | Ne pas promouvoir un dossier en compétence lançable |
| M4 | Racines projet/utilisateur avec collision de nom, y compris masque local sans record | Priorité officielle par nom de dossier ; copie masquée non réactivée | Racines externes non autorisées refusées |
| M5 | Record `bmod` seul, record+skill, compétence/module manquant | Métadonnées séparées des invocables ; appartenance et invocation exacte sourcées | Présence ne vaut pas runtime qualifié |
| M6 | Aide implicite, knowledge explicite, topics et migrations | Provenance, contenu chargé ou référence seule distingués, migration jamais exécutée | Aide absente/illisible/hors portée explicitement indisponible |
| M7 | Config centrale et compétence à trois couches, override user, tableaux code/id ; TOML invalide | Fusion officielle constatée ; `_bmad/config.user.toml` ignoré | Personnalisation résolue ne vaut pas autorisation d’exécution |
| M8 | Initiative absente, multiple, active et choix Madness divergent | Contexte résolu et sélection locale séparés ; conflit avant invocation | Aucune écriture de configuration ni réattribution d’historique |
| M9 | Output hors projet, chemins relatifs/absolus et traversal | Frontière canonique du profil et refus explicite | Un comportement permis par BMad n’élargit pas implicitement Madness |
| M10 | Liens/jonctions Windows et hardlinks vers extérieur, remplacement d’un ancêtre | Refus avant lecture exploitable ou appel d’outil | Prouver réellement le cas Windows, aucun skip vert |
| M11 | UTF-8 invalide, taille/nombre/profondeur excessifs | Lecture/énumération bornées, erreur typée et capacité limitée | Ne pas tronquer silencieusement une aide |
| M12 | Source modifiée entre découverte/lecture/action, référence devenue absente | Révision différente/invalidation et refus de l’ancienne invocation | Aucun ancien reçu présenté frais |
| M13 | Entrée tickets TOML sans feuille, plan présent/absent, statut contradictoire | Identités et chaque preuve conservées ; statut du plan sourcé séparément | Présence/built ne devient pas validation humaine |
| M14 | Compétence installée non qualifiée, script ou hook non fiable | Aide descriptive possible si sûre ; lancement refusé, aucune exécution | Commande exacte conservée sans promesse de support |
| M15 | Fixtures et installation observées via outils locaux contrôlés | Zéro réseau/agent/écriture réelle ; fixtures nettoyées même en échec | Échec d’instrumentation conservé, aucune réussite supposée |

</frozen-after-approval>

## Code Map

- Reprise du30octobre : sous environnement autorisé, ciblés3/3(run0979) puis matrice13/15(run77868) avec seuls dépassements15s de la garde native M15 et de knowledge M1. Budget expérimental Windows60s/appel, sorties4Mio et lanceur600s conservés. Pas de retry ni de relâchement des refus ; contrôler les durées réellement observées et toute la matrice sur les nouveaux octets. Les échecs, leurs limites et leurs preuves restent historiques. Le parent termine l'implémentation incomplète après disparition du worker précédent ; revues fraîches toujours requises.

- Reprise2 : lier réellement la résolution aux octets admis. `config_utils.merge_layers` est la primitive officielle pure ; parser les trois couches capturées puis les fusionner par cette primitive, ou résoudre leur snapshot sûr. Le contexte doit être calculé depuis cette même collecte, sans accepter une résolution indépendante comme autorité. Une ancienne résolution fournie doit être refusée, jamais habillée de nouvelles empreintes. `fresh_context` recapture ET résout les nouvelles couches. M8 doit écrire l’initiative dans la fixture ; M12 couvre un changement entre résolution initiale et collecte, à skills inchangées.
- Reprise2 : le fingerprint produit734fichiers demeure une preuve de son périmètre, pas l’inventaire de tous les octets exécutables. CPython lit aussi les caches `.pyc` malgré `-B`, et Windows accepte `.pyw`. Avant le PREMIER UV/Python, qualifier tous les formats/chemins effectivement importables, dont caches, modules startup Lib/DLLs, `pyvenv.cfg` à la base ET son parent, et `.pth` ordinaires à la base (site.py les parcourt aussi sous Windows). Même garde sur les probes. Deux stratégies cohérentes restent dans le périmètre : empreinte effective complète avec complément des formats/caches, ou runtime copié possédé fermé dont les seuls octets exécutables admis sont verrouillés. Choisir et prouver une seule voie, sans modifier le runtime réel. Une simple note de limite ne remplace pas les garanties de la voie retenue.
- Cas de reprise2 : ancienne résolution alpha/fichiers beta refusée ou contexte beta résolu de ses propres octets ; mutation après première résolution invalidée. Caches existants de ctypes/importlib, `.pyw`, legacy `.pyc`, `Lib/sitecustomize.pyw/.pyc`, configuration venv parent et `.pth` à la base sont éprouvés en données/copies possédées ; variantes non admises refusées AVANT lancement, sans jamais exécuter leurs charges. Préserver les preuves antérieures et distinguer reçu historique valide d’une capacité qualifiée courante.

- Reprise1 après revue : les fonctions officielles ne remplacent pas les gardes du profil. Les précisions ci-dessous et `rederivation.md` règlent six contre-exemples sans changer l’intention figée. Le ZIP `iteration-0.zip` conserve intégralement le premier banc/proofs ; lire ses sources pour préserver les cas utiles, sans exécuter l’ancienne voie.
- `src/adapters/bmad/runtime.ts:8–26`, `profile.ts:65` : reprendre réellement le modèle de runtime de base hors projet, empreinte des DLL/stdlib/pth et `-I -S -B`, environnement filtré ; ne pas lancer le redirecteur venv. Les deux EXE seuls et `pyvenv.cfg` mutable ne qualifient pas le runtime. Aucun vrai runtime ni sa configuration ne doit être modifié pour tester ; éprouver la sélection et les empreintes sur copies possédées/fixtures.
- `roster.py:agent_identity` masque ConfigError : prévalider les personnalisations effectivement exploitées, conserver les erreurs sourcées/refuser la capacité au lieu d’une identité de repli inexpliquée. `knowledge` exige aussi la relation inverse module→compétence : une compétence déclarée par un autre module est une contradiction, pas seulement une présence globale.
- `tickets.py:join_plans` écrase les champs de feuille : capturer et conserver entrée TOML, feuille, plan, tracker et leurs empreintes/champs séparés avant jointure. La projection officielle reste disponible mais ne remplace pas ces preuves ; aucun reçu uniquement temporaire supprimé au nettoyage.
- `context()` : collection dédiée des seuls fichiers d’initiative exploités, bornée cumulativement avec leur configuration, noms/identités/empreintes dans un reçu de contexte distinct de celui des skills. Recapture et invalidation sur changement d’initiative indépendamment des skills ; pas de scan récursif aveugle de tous les livrables binaires. Éprouver17fichiers de1Mio contre la limite16Mio, et modification à skills inchangés.
- Reproduction : vérification du reçu existant strictement en lecture seule. Chaque nouvelle exécution écrit ses preuves dans un emplacement neuf possédé sans remplacer les preuves scellées ; sélection/promotion et scellement sont explicites. Éprouver réellement cette séquence, pas seulement corriger une phrase. `uv run --offline --no-project --no-config` reste la voie prescrite des scripts Python.

- `_bmad/scripts/{knowledge,config_utils,resolve_config,resolve_customization,roster}.py` : copies identiques aux sources sous `.agents/skills/bmad/scripts/` selon investigation ; relever à nouveau leurs empreintes. `knowledge.scan` privilégie le premier dossier du même nom même sans record ; `resolve_skill` ne vérifie pas l’exécutabilité. `bmod.toml` porte `6.13.0-next`. Importer/exécuter seulement les outils de provenance épinglée, jamais ceux du projet analysé.
- `config_utils.py` : trois couches centrales (`config.toml`, custom/config puis custom/config.user) et trois couches compétence (`customize.toml`, custom/skill puis custom/skill.user) ; tableaux code/id remplacent l’élément complet. `knowledge` borne ses aides mais pas les manifestes : le banc doit apporter ses propres préconditions de sûreté.
- `resolve_customization.py`, `tickets.py` : passer explicitement la racine ; BMad peut résoudre un output externe, le profil Madness doit le refuser. Roster/personas et topics ne prouvent pas invocation.
- `src/adapters/bmad/profile.ts`, `runtime.ts`, `forge.ts`, `forge-manifest.ts` : références de bornage, canonicité, relecture/identité/empreinte et runtime maîtrisé. Mary/Forge seulement ; pas de découverte ni d’aide générique livrée. Ne pas modifier ces fichiers.
- `src/core/{ports,dialogue,application}.ts`, `src/contracts/dialogue.ts` : cœur propriétaire des contrats, capture de contexte et reçus ; union d’invocation limitée à Mary/Forge. Les propositions G2 restent documentaires, aucune extension opportuniste.
- `tests/{dialogue-profile,dialogue-runtime,forge,forge-protocol}.test.mjs` : réutiliser les cas de frontières et courses pertinents sans réexécuter la suite produit inchangée comme preuve G2.

## Tasks & Acceptance

**Execution:**
- [x] `qualification-profil-g2/{prototype.*,scenarios.*,fixtures-*}` — banc isolé et fixtures jetables, commandes fixes, sorties/durée bornées, aucune exécution de contenu projet ; privilégier les primitives gérées réellement observées, leur préflight et leurs limites plutôt qu’un parseur parallèle prétendument officiel.
- [x] `qualification-profil-g2/{results.json,sources.md,*.log}` — exécuter chaque ligne M1–M15, enregistrer tests et observations séparément, versions/empreintes, appels et refus, nettoyage et conservation locale.
- [x] `qualification-profil-g2/profil-g2.md` — répondre au spike : profil exact, états et capacités ; racines/priorité/personnalisation ; contrats documentaires diagnostic, aides/recommandation, contexte/invocation et reçus/provenance ; tickets sans feuille ; décisions de périmètre et inconnus pour2.17/2.2 et clôture future2.16.
- [x] `qualification-profil-g2/verify.*` — vérificateur fermé des preuves, couverture de matrice et absence de modifications produit/managed ; ne pas lire ni copier coffre/AppData.

**Acceptance Criteria:**
- Given l’installation et les fixtures définies, when le banc est exécuté, then chaque ligne M1–M15 a une assertion passée sans skip et les capacités retenues renvoient à une preuve ; une limite non testable est signalée sans déclarer le scénario réussi.
- Given le rapport, when Sally puis le tracer le consomment, then ils disposent d’un contrat précis sous l’autorité du cœur/Winston et de refus reproductibles, sans prétendre G2 intégré ni lancement général.
- Given ce lot isolé, when les empreintes finales sont comparées, then sources produit/gérées/configurations observées sont inchangées et aucun compte, réseau ou modèle n’a été requis.

## Implementation Notes

2026-10-30 — Reprise autonome demandée explicitement. Ciblés M8/M12/M15 passés3/3en225,369s sur run0979a45a91e8464b94fe4eb0f903b527 ; matrice run77868cdcf810403ba1a846c8990cdb0e13/15en360,737s, sans skip,558inputs conservés et15fixtures retirées. M10 Windows réel passe. Les deux échecs sont les délais15s de la garde native et knowledge local, non des refus de données relâchés. Seul budget du banc porté à60s, hors produit ; les128+1sources indépendantes et le bloc figé04d restent inchangés. Protection -text ajoutée pour les octets de ce seul plan. Aucune nouvelle invocation du renderer BMad ni action humaine réseau.

2026-10-28 — Complément de reprise1 demandé par le parent avant revue : uv0.13.0 inspecte Python avec `-I -B` sans `-S` (source amont versionnée citée dans sources.md). Pin produit734fichiers conservé et étendu explicitement pour la voie de démarrage : liste exacte d’un `.pth` réel de151octets/SHA2638ce…, seuls imports inconditionnels stdlib épinglés, branche `_distutils_hack` neutralisée par `SETUPTOOLS_USE_DISTUTILS=stdlib` dans l’environnement enfant. Absences de sitecustomize/usercustomize et surcharges de chemin vérifiées avant lancement. Aucun runtime/hook réel modifié. UV réel sur copie exacte, observation du harnais et simulation statique du branchement distingués ; les hooks de fixtures modifiés sont refusés avant lancement, jamais exécutés. Les deux runs précédents et leurs sceaux restent historiques et immuables ; nouveaux runs nécessaires pour ce complément.

2026-10-28 — Reprise1 : primitives sûres du banc archivé conservées, six contre-exemples re-dérivés. Runtime de base hors projet et uv épinglés,734fichiers DLL/stdlib/.pth et pin identique au produit ; contrôle avant premier Python, `-I -S -B`, environnement filtré et temp/cache possédés. Relation réciproque module/skill et prévalidation de l’identité roster ; erreurs sourcées avant repli. Sources brutes/empreintes/champs TOML, feuille, plan et tracker sérialisés avant la jointure officielle. Reçu context-v1 indépendant des skills, trois configurations et seules initiatives exploitées, plafond cumulé16Mio ;17fichiers de1Mio refusés et mutation d’initiative invalidée à skills inchangées. Chaque exécution crée `runs/run-<UUID>/`, scellement create-only et sélection/promotion distincts. Aucun produit/managed/configuration personnelle ni runtime réel modifié.

Premier run reprise1 `run-ff709efe65944deab605bd2b17dace61` :15/15tests,112assertions,20observations,20appels gérés réussis,558inputs identiques, fixtures retirées et63contrôles fermés au scellement explicite. Second run neuf `run-3916a247ce194665972ec45091ea0d66` : mêmes15/15,112assertions,20observations,558inputs et63contrôles. Relecture du premier63/63 après seconde exécution ;16fichiers du premier, sceau compris, identiques individuellement dans reproduction.json. Promotion explicite du premier ; aucun ancien reçu remplacé. Les faits du tour0 ci-dessous sont historiques, archivés, sans équivalence de preuve avec cette reprise ; les revues et le verdict final demeurent au parent.

2026-10-28 — Banc Python isolé livré dans `../qualification-profil-g2/`, sans modification produit/gérée. Les fonctions officielles épinglées `knowledge`, `config_utils`, `roster` et `tickets.load_folder` consomment des snapshots de données précontrôlées ; ni scripts du projet analysé, ni CLI à hook, ni `tickets.central_config` non fiable ne sont exécutés. CPython3.12.14 et scripts verrouillés SHA-256 ; UTF-8 strict, 1Mio/fichier,16Mio/corpus,1024entrées/profondeur12,15s/4Mio par flux. Garde native du handle avant lecture, reparse/hardlinks refusés, révision recapturée avant usage. Worker limité aux seules racines jetables possédées.

Installation réelle : trois modules6.13.0-next,27compétences,3aides chargées,43topics et2migrations référencés,17entrées sans feuille. Diagnostic partiel : `method` déclare `bmad-retrospective` absent ; absence conservée sans installation. Contrats documentaires proposés au cœur pour Sally2.17/tracer2.2 ; aucune invocation générique ni G2 intégré qualifiés. Premier essai sandbox14/15 (WinError5 création hardlink) conservé ; le final autorisé hors sandbox exerce réellement hardlink/jonction/remplacement d’ancêtre et nettoie ses fixtures. Échec du cache uv initial également conservé, sans succès inventé.

## Plan Change Log

2026-10-28 — Reprise2 déclenchée par QV1-1/QV1-2/BV1-2 (bad_plan), avec QV1-3/BV1-1/RV1-1 (patch) repris. Le plan antérieur n’imposait pas assez explicitement résolution depuis les mêmes octets ni inventaire d’exécution au-delà du fingerprint produit. État évité : ancien contexte déclaré frais, ou code importable non verrouillé pendant le démarrage. KEEP : gardes canoniques et NTFS, aide réellement lue sans lancement général, appartenance réciproque, refus roster, preuves séparées des tickets, plafonds/révision du contexte, uv prescrit offline, reçus create-only, conservation et absence de fournisseur. Archive iteration-1.zip du parent avant retrait du code actif ; anciens runs conservés intacts. Bloc figé et baseline inchangés, aucun intent_gap.

Parent,2026-10-28 — Relance indépendante `run-5314623c7e8c43d9acd6848198bec60d` :15/15tests,125assertions,21observations,558inputs identiques et fixtures retirées ; scellement65/65, manifestee2f8e03484d222e3eaa9ed19b11c2162f7be8b2e8591ba2944093f5c63cc65e8. Référence sélectionnée c719… vérifiée auparavant63/63 sans modification. Protection locale `.gitattributes` : octets exacts `-text` pour la qualification et preuves générées/copies historiques `-diff`, avec contrôle indépendant des filtres Git ; les sources et les contrats demeurent en diff textuel. Pas de changement du code exécuté ni nouveau test produit requis pour cette hygiène des preuves.

2026-10-28 — Reprise1 déclenchée par Q2/B1/B3 (bad_plan), avec Q1/Q3/B2 (patch) repris dans la réimplémentation cohérente. La Code Map précisait trop peu les garanties absentes des fonctions gérées et l’immuabilité de la preuve lors d’une reproduction. Ajouts : runtime effectif isolé/empreinte complète ; garde de roster et appartenance réciproque ; sources séparées des tickets ; collecte contextuelle bornée/révisionnée ; nouvelle exécution dans un emplacement neuf. État évité : rapport vert annonçant des garanties non exercées ou détruisant son propre reçu. KEEP : M1–M15 réellement exécutés, garde du handle avant lecture, refus NTFS, snapshots sans code projet importé, fusion/knowledge/tickets officiels, absence de runtime générique promis, conservation produit/gérée, nettoyage et échecs historiques explicites. Bloc figé inchangé ; aucun intent_gap ni nouvelle décision produit.

## Review Triage Log

2026-10-30 — Troisième tour : les deux relecteurs frais ont rendu leurs constats avant triage. Quatre constats vérifiés par le parent, trois medium et un low ; zéro false/maybe-false/carried. Deux groupes bad_plan déclenchent une reprise3 ; les deux patch sont repris avec elle, aucun différé ni intent_gap. Les73/72contrôles réussis du run517… ne prouvent pas les nouveaux cas manquants.

| Constat | Verdict / route | Vérification parent |
|---|---|---|
| QV2-1 imports du banc hors fermeture | medium / bad_plan | Les deux bootstraps insèrent HERE en tête de sys.path avant imports ; les gardes ferment734fichiers de stdlib, pas HERE. SourceLoader lit les caches avant le flag d’écriture -B ; la provenance des octets exécutés peut diverger du reçu de sources. Nouveau chemin, pas le constat runtime déjà corrigé. |
| QV2-2 arrêt global laisse fixture/run incomplet | medium / bad_plan | Kill(true) précède un finally limité à runtime/cache. Les callbacks unittest ne peuvent plus s’exécuter ; le prochain verify refuse fixtures restantes et le parent lit results.json sans état d’interruption. Échec atteignable du lanceur propre au banc, pas un arrêt OS arbitraire. |
| QV2-3 journal Python annoncé absent | low / patch repris | Test-Path constate absents readonly, seal et promotion logs. Console.Out.Write n’alimente pas Tee-Object. Les72contrôles ont été réellement reçus par l’outil et18hashes sont conservés, mais le lien persistant ne donne pas cette sortie. Capturer un vrai flux natif ; ne pas fabriquer un journal rétroactif. |
| BV2-1 parsing des preuves Windows | medium / patch repris | FRONTMATTER_RE exige ---LF ; ticket_proofs parse raw.decode(utf8), tandis que read_text officiel utilise utf8-sig et la normalisation universelle. CRLF/BOM admis perdent fields/collections tout en gardant le statut fusionné. Normaliser seulement la vue de parsing et conserver les octets bruts. |

2026-10-28 — Deuxième tour, deux relecteurs frais ; six medium (cinq constats des lenses et un complément parent), zéro high/low/false/maybe-false. Trois groupes : cohérence de résolution (bad_plan), couverture des octets importables (bad_plan), contrôles préalables parent (patch repris dans la re-dérivation). Aucun différé. Les refus roster et les plafonds/révisions d’initiative du premier tour sont recontrôlés résolus ; la nouvelle cohérence de configuration reste distincte.

| Constat | Verdict / route | Vérification parent |
|---|---|---|
| QV1-1 résolution indépendante du reçu | medium / bad_plan | `context` prend config en paramètre et capture ensuite les fichiers sans comparer ; M8 alpha n’existe pas sur disque. `fresh_context` réutilise ce même config, donc accepte l’ancienne résolution avec nouveaux octets. |
| QV1-2 caches exécutables hors pin | medium / bad_plan | Importeur CPython1075–1135 lit/compile un cache valide puis ne teste dont_write_bytecode que pour écrire ; runtime_manifest ignore __pycache__/pyc, dont ctypes réellement présent. |
| QV1-3 pyvenv parent trop tard | medium / patch repris | Le lanceur ne teste que base/pyvenv.cfg avant UV ; select_base teste aussi le parent mais après le premier Python. |
| BV1-1 pyvenv parent | medium / patch repris, même groupe | site.py523–551 confirme la recherche parent et l’activation de ses sites pendant l’inspection UV ; la garde de probe ne reprend pas select_base. |
| BV1-2 formats startup non couverts | medium / bad_plan, même groupe QV1-2 | .pyw est importable sur Windows et .pyc sans source aussi ; Lib/DLLs ne sont pas contrôlés pour sitecustomize, ces formats échappent au pin. |
| RV1-1 .pth ordinaire à la base | medium / patch repris | Lecture primaire de site.py367–405 : sous Windows getsitepackages inclut le préfixe lui-même et Lib/site-packages. Les gardes n’énumèrent les .pth ordinaires que dans ce dernier ; un .pth racine échappe à l’inventaire. Aucun payload exécuté pour cette constatation. |

2026-10-28 — Premier tour, Quick + audit high ; six medium, zéro high/low/false/maybe-false, aucun différé. Sources inspectées par parent et résultats initiaux conservés dans iteration-0.zip. Les corrections patch sont reprises avec les trois bad_plan ; pas de correction dispersée avant la réimplémentation.

| Constat | Verdict / route | Vérification parent |
|---|---|---|
| Q1 appartenance inverse | medium / patch, repris | `listed_member` contrôle seulement le record de la skill ; member-missing utilise l’ensemble global et accepte une déclaration par un autre module. |
| Q2 preuves de feuille perdues | medium / bad_plan | `join_plans` fait row.update des champs du plan ; wrapper ne conserve que rows, reçu brut M13 temporaire non sérialisé puis supprimé. |
| Q3 reproduction détruit le sceau | medium / patch, repris | `scenarios.main` réécrit UUID/date/logs ; `verify` exige les anciens hashes. La procédure sans scellement explicite échoue et écrase le reçu précédent. |
| B1 runtime incomplet | medium / bad_plan | Verrou initial limité aux deux EXE ; lancement du redirecteur venv sans -S. pyvenv.cfg réel choisit le home et site reste actif avant audit, à la différence du runtime produit. Aucun effet observé n’est déduit. |
| B2 roster masque TOML invalide | medium / patch, repris | `agent_identity` intercepte ConfigError/OSError et rend {}, sans problème ; M7 ne teste que le chargement direct. |
| B3 contexte hors plafond/révision | medium / bad_plan | `context` lit directement jusqu’à1024initiatives de1Mio sans TOTAL_LIMIT ni reçu de contexte ; le source_revision M1 porte seulement les skills. |

## Design Notes

Mandat humain autonome : plan et décisions nécessaires délégués, sans nouvelle confirmation de routine. Aucun écart d’intention identifié ; les inconnus techniques sont précisément la matière du spike. Route full pour un banc significatif dépassant100 lignes.

Le worker possède seulement les fichiers de qualification décrits et les notes/tâches de ce plan hors bloc figé. Il n’est pas seul dans le dépôt : respecter les autres modifications, ne pas les annuler, s’y adapter. Parent propriétaire des revues, preuves parent, continuité, tickets/epic et commits. Aucun nouveau sous-agent d’implémentation nécessaire.

Une revue Quick fraîche est complétée par une contre-analyse indépendante des frontières canoniques, personnalisations et capacités. Cette seconde lecture répond au contrôle high de l’epic ; lancer les deux avant triage. Aucun rôle Sally ou Winston réellement invoqué ne sera déduit du rôle d’un relecteur technique.

## Verification

- 2026-10-30 : run courant517afc048ef54c29806faaf1e4540feb,15/15tests,230assertions/21observations/23appels, zéro skip ;446,276s,558inputs identiques et15fixtures retirées. Appels maximum19,360s knowledge et18,250s roster : preuve du budget15s insuffisant avant correction à60s. Scellement73/73 et promotion73/73, manifeste19e6c9a7888c82c4428e4790307dfdfddd46ab9686dec14f55ea88e1bbf2fdb2. Vérificateur parent livré en lecture seule :129sources,80fichiers historiques et deux archives inchangés ; reçu schema2courant distinct des cinq schema1historiques et cinq essais ciblés/échoués non scellés. Voir [preuve parent](../qualification-profil-g2/parent-verification.md). Aucun changement produit ni appel fournisseur. Revues fraîches finales encore requises.

- Complément de démarrage : `-Action record-startup-pins` a étendu explicitement le verrou une seule fois, sans changer le pin734fichiers ni les pins des outils ; ancien verrou conservé dans les deux runs scellés historiques. Nouveau `-Action run` → `run-c71945964aee4e2883622a8216a42c9b`,15/15tests,125assertions,21observations,558inputs identiques, fixtures retirées en147,340s. `-Action seal -RunId <id>`65/65 ; manifeste9f007847527c7a06722df3997f87db2d4a6b35e39b2df05c59ea717847d44437. Son M15 garde le démarrage réel UV sur copie exacte et refuse les hooks de fixtures avant lancement ; aucun nouveau code de fixture exécuté. Les deux runs112assertions ci-dessous restent historiques du complément de démarrage, non preuves de ce dernier.
- Reproduction du complément : `run-2602aa3865e34278b6beeb32e195aa6d`,15/15tests en151,106s,125assertions/21observations,558inputs identiques et nettoyage complet ; second scellement65/65, manifesteff1488e3f05c0042521af28bbf41dbf8df1d58c6b14500e1b9d308238acfdf02. `-Action verify -RunId run-c719…`63/63 après cette reproduction. Les logs startup-first-seal.log, startup-second-seal.log et startup-first-readonly-verify.log gardent les sorties ; relecture seule ne dépend pas de l’égalité du code courant avec une ancienne version scellée, tandis qu’un nouveau scellement/promotion l’exige.
- Fermeture de reproduction : ancien runff709… relu63/63 avec le vérificateur courant, puis promotion explicite de c719…65/65. Reproduction-startup.json conserve16empreintes avant/après identiques du reçu corrigé et32empreintes identiques des deux runs historiques ; selected-run.json désigne c719… et ses sources/preuves. Aucun fixtures-run-* ni temp/cache uv résiduel. Aucune modification produit/gérée/configuration observée, aucun réseau/compte/modèle requis. Les revues Quick/frontières high, la vérification parent et le verdict de Build restent au parent.

- Reprise1 : `& '_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\run.ps1' -Action run` — base épinglée via uv offline/no-project/no-config, sans venv. Première exécution complète autorisée hors sandbox pour ses seuls liens NTFS possédés :15/15tests,112assertions,20observations,558inputs identiques et nettoyage complet.
- `& '_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\run.ps1' -Action seal -RunId 'run-ff709efe65944deab605bd2b17dace61'` —63/63contrôles ; manifeste054fdc263166f0f82048d7293ed8532e895fa89b9f7ca70ab8eac9d27f20238c. Vérifier le même reçu utilise `-Action verify -RunId <id>` ; aucun sceau ni résultat n’est mis à jour par cette commande.
- Les commandes/résultats ci-dessous décrivent le tour0 archivé uniquement ; la voie venv n’est plus une reproduction admise de reprise1.
- Reproduction réelle : même `-Action run`, nouvel id `run-3916a247ce194665972ec45091ea0d66`,15/15tests en127,184s,558inputs identiques et nettoyage complet. `-Action seal -RunId <second>`63/63, puis `-Action verify -RunId <premier>`63/63 et `-Action promote -RunId <premier>`63/63. Reproduction.json conserve les16empreintes avant/après identiques du premier. Second manifestebbc5f6582cb22a1d14c0e8646df680ebcb2f0c2c46d2a64abdb91e038fbe9717 ; journaux first-readonly-verify.log, second-seal.log et promotion.log. Aucune nouvelle exécution ne rafraîchit le verrou ni un sceau précédent.

- Commande finale réellement exécutée depuis la racine : `& 'C:\Users\UP60066553\scoop\apps\uv\current\uv.exe' run --offline --no-project --no-cache --python 'C:\Sources\madness\.venv\Scripts\python.exe' python -B 'C:\Sources\madness\_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\scenarios.py'` — 15/15 tests,87assertions,15observations, zéro skip ; 558inputs identiques avant/après et fixtures retirées. Les seuls essais de socket/écriture sont des probes d’audit volontairement refusés, aucun effet réseau ni moteur.
- `& '.venv\Scripts\python.exe' -B '_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\verify.py' --seal` —46/46contrôles fermés ; `evidence-manifest.json` scelle banc, sources et preuves. Reproduction ultérieure sans `--seal` vérifie les empreintes sans les rafraîchir.
- Durcissement des racines du worker : M15 rouge (`Refusal not raised`) puis vert isolé1/1 et final15/15 ; préflight répété dans le worker. Logs d’instrumentation et premier run refusé conservés, pas de réexécution de la suite produit inchangée comme preuve G2. Revues Quick/frontières high et preuves parent restent sous la responsabilité du parent.

- Depuis la racine, exécuter les tests du banc avec `uv run` pour Python ou `node --test` pour Node ; commandes exactes à inscrire ici après choix technique. Zéro tests ignorés ; M1–M15 couverts, tests de liens Windows réellement exécutés.
- Vérifier les scripts officiels/versions locaux et les entrées avant/après ; rapport de conservation fermé et audit indépendant. Une lecture de configuration n’exécute ni setup/update ni render.
- Vérifier le diff complet depuis la baseline, la constance du bloc figé, les liens documentaires, `git diff --check`, puis revue Quick et frontière high. Suite produit/build/installateur inutiles en l’absence de modification du produit.
