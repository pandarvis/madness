# Profil G2 candidat — reprise2 hors produit

Le candidat qualifie l’observation et le chargement de données sûres de
l’installation locale exacte `6.13.0-next`, avec refus reproductibles. Il fournit
des contrats documentaires à Sally2.17 puis au tracer2.2 sous l’autorité du cœur
et des AD-2/3/7 de Winston. Aucun G2 intégré, catalogue/aide UI ou lancement
général n’est livré. Mary/Forge conservent leur profil produit existant.

## État et capacités

L’installation observée comporte trois modules (`core-tools`, `method`,
`toolsmith`),27descripteurs de compétences, trois aides de module chargées,
43topics et deux migrations référencés. Le diagnostic est **partiel** :
`method` déclare `bmad-retrospective`, absente. Aucun setup/réparation n’est
déclenché ; les capacités indépendantes et les aides sûres restent lisibles.
Les17entrées de l’epic sont identifiées sans feuille matérialisée. Statuts du
plan, de la feuille et du tracker restent chacun sourcés ; aucun ne prouve une
acceptation humaine. Le résultat courant nommé et scellé est précisé ci-dessous.

| Capacité | Preuve et portée |
|---|---|
| Présence/format | M1–M3 : exact local, absent, marqueur ancien et preview inconnue distincts. Ancien observé ne signifie pas exécutable. |
| Modules/skills | M3–M5 : métadonnées séparées ; SKILL, appartenance réciproque et dépendances vérifiés ; commandes descriptives exactes, runtime général indisponible. |
| Aide | M6/M11 : contenu réellement lu et chargé, références topics/migrations distinctes ; absent, UTF-8 invalide, hors portée ou trop grand refusés sans troncature. |
| Personnalisation/roster | M7 : trois couches officielles et refus sourcé avant tout repli d’identité masquant une erreur. |
| Initiatives/contexte | M8/M9/M12 : sélection locale distincte ; contexte résolu depuis les mêmes octets que son reçu ; conflit et mutations bloquent l’ancienne invocation. |
| Tickets | M1/M13 : entrée TOML sans feuille ; sources complètes de feuille/plan/tracker conservées avant jointure. |
| Recommandation native `$bmad` | Non qualifiée ; le tracer2.2 doit transmettre le bundle réel et obtenir un reçu natif. |
| Exécution générale | Non qualifiée M14 ; une invocation exacte copiable n’est pas une capacité lançable. |

États proposés : `absent`, `legacy-observed`, `unknown`, `partial`,
`candidate-observed`, `incompatible`, `invalidated`, `error`. Une version non
éprouvée reste unknown ; frontière ou configuration refusée bloque les capacités
touchées avec code/source. L’état agrégé ne masque pas leurs différences.

## Racines, configuration et fraîcheur

Le cœur autorise explicitement la racine canonique projet et les racines de
skills réellement actives de l’hôte, ordonnées projet puis utilisateur. Aucun
home réel n’est exploré ici. La priorité officielle porte sur le **nom du
dossier** : un masque local sans record empêche de réactiver la copie utilisateur.
Une sortie externe permise par BMad n’élargit pas l’autorité Madness.
Output relatif/absolu interne et `{project-root}` interne admis ; traversal,
URI, chemin relatif à lecteur et sortie externe refusés.

Centrale : `_bmad/config.toml`, `_bmad/custom/config.toml`,
`_bmad/custom/config.user.toml`. `_bmad/config.user.toml` est ignoré.
Compétence : `customize.toml`, `_bmad/custom/<skill>.toml`, puis
`<skill>.user.toml`. Tables récursives, tableaux ordinaires ajoutés, éléments
à code/id remplacés **en entier**. Un TOML présent invalide conserve son erreur.
Roster prévalide chaque personnalisation exploitée avant `agent_identity` ;
une identité de repli ne cache pas ConfigError. L’appartenance est réciproque :
la présence d’une skill déclarée par un autre module est une contradiction.

Le reçu `context-v2` porte couches/octets/identités/empreintes et résolution
`config_utils.merge_layers` **de ces mêmes octets**. Une ancienne résolution
fournie séparément est comparée et refusée si divergente. `fresh_context`
recapture et résout ; il ne garde jamais alpha sur de nouveaux octets beta.
M12 éprouve ce cas, avec skills inchangées. M8 écrit réellement l’initiative
alpha dans la fixture et distingue l’initiative active de la sélection locale.
Une navigation ne réattribue aucun échange et n’écrit pas la configuration.

Bornes expérimentales : UTF-8 strict,1Mio/fichier,16Mio/corpus,1024entrées,
profondeur12 pour les skills. Le contexte borne configurations et seuls fichiers
immédiats `<initiative>/<initiative>.md` exploités, sans parcourir les binaires.
M11 refuse17fichiers de1Mio. Ce ne sont pas des limites officielles de BMad ou
de nouveaux choix UI. Reparse/symlinks/hardlinks et types irréguliers refusés ;
handle Windows et ancêtres contrôlés avant lecture. M10 exerce réellement les
hardlinks, jonctions et remplacement d’ancêtre. Ajout, suppression, remplacement
ou mutation de contenu invalide le reçu, indépendamment de l’horloge.

Les fonctions gérées travaillent sur des snapshots bornés de données, jamais
sur du Python du projet analysé. Le runtime courant est une **copie possédée
fermée** des734fichiers déjà épinglés ; les caches originaux ne sont pas copiés.
Avant le PREMIER UV, la garde native contrôle l’ensemble exhaustif des octets,
base/parent venv et l’absence de toute entrée supplémentaire. Workers et probes
répètent la garde Python. M15 éprouve les caches ctypes/importlib existants en
données et14variantes non admises, dans les deux gardes, sans exécuter leurs
charges. Seule la copie exacte sert au probe UV positif. `uv run --offline
--no-project --no-config --no-cache`, Python `-I -S -B`, environnement filtré et
temp/cache possédés. Voir [sources.md](sources.md) pour le périmètre exact et la
distinction avec les garanties historiques insuffisantes de `-B` seul.

La fraîcheur est un contrôle au point de préflight ; l’intégration devra le
répéter au point d’effet. Aucune immuabilité du système de fichiers ou sandbox
contre un adversaire OS n’est promise. Hooks, migrations, `setup --status`,
`render_skill` et configuration personnelle ne sont pas exécutés ou modifiés.

## Contrats documentaires proposés au cœur

| Contrat | Données et invariants |
|---|---|
| `EvidenceRef` | Source, racine autorisée, chemin relatif, SHA256, révision, observation et origine projet/utilisateur/géré ; portée et fraîcheur courante/invalidée/historique. |
| `ProfileDiagnostic` | Version exacte/runtime, racines ordonnées, révision et état agrégé ; capacités indépendantes, disponibilité, refus/preuves/récupération. Aucune installation implicite. |
| `KnowledgeBundle` | Module/record, skills couvertes, documents avec texte réellement chargé et preuve ; topics/migrations en références seules ; problèmes et couverture exacte. |
| `AgentRecommendation` | Conversation/tour natifs, bundle réellement transmis et ses empreintes, réponse brute reçue, raisons et alternatives de l’agent. Sans reçu, aucune mention « BMad recommande ». |
| `ActionDescriptor` | Module/skill, invocation Codex exacte `$<nom-dossier>`, objectif/entrées/conditions/effets/livrables sourcés ou inconnus. `copyable` séparé de `launchability`. Pas de quota ou séquence obligatoire. |
| `CapturedBmadContext` | Projet/racine canonique, profil/révision, output confiné, couches et résolution du reçu context-v2 ; initiative BMad et sélection Madness séparées, conflits/preuves. Les opérations/conversations gardent leur contexte capturé. |
| `InvocationReceipt` | Opération, contexte/descripteur/révisions contrôlés avant envoi, texte exact, connecteur/connexion/capacités, accusé natif, résultat connu/inconnu/échec. Copier n’envoie rien ; accusé n’est pas accord humain. |
| `TicketEvidence` | Conteneur/id, entrée TOML, feuille optionnelle avec ses champs, plan optionnel et son ticket/statut, tracker, contenus/empreintes et contradictions avant jointure. built/fichier présent n’est pas une acceptation. |

Une action exigeant une initiative doit résoudre explicitement un désaccord
avant invocation ; une action sans initiative suit ses propres conditions.
Un diagnostic invalidé reste historique et impose relecture ciblée. Aucune
union d’invocation produit n’est étendue par ces propositions.

Sally2.17 doit représenter diagnostic partiel, aide chargée/réponse native,
descriptif/copiable/lançable, active/sélection et statut/accord humain, en
conservant projet/conversation/brouillon pendant refus/relecture. Palette et
contrats visuels adoptés restent l’autorité. Le tracer2.2 doit qualifier `$bmad`
réel, transmettre l’aide, obtenir le reçu natif et conserver la réponse et les
alternatives. La clôture2.16 vérifiera ces consommateurs intégrés et le paquet.
Autres versions/OS/racines, hooks tiers, initialisation et dépendances complexes
restent non qualifiés. R32/Q8/Q9 ne reçoivent ici aucune mesure, aucun coût ou
suivi de notre développement. SIWC, cache réseau et persistance sont inchangés.

## Reproduction et conservation

Depuis la racine dans PowerShell7, `run.ps1 -Action run` crée un emplacement
neuf `runs/run-<UUID>/` et copie son code/verrou exécutés. `-Action seal -RunId
<id>` crée le sceau une fois ; `-Action verify -RunId <id>` ne modifie aucune
preuve. `-Action promote -RunId <id>` crée le reçu de promotion distinct et
actualise le seul pointeur selected-run. Chaque lancement retire sa copie du
runtime et son cache en finally. Liens Windows : un refus de droits reste un
test échoué, jamais un skip vert.

Les cinq anciens runs et les archives iteration-0/1 restent bit-identiques et
historiques. Le vérificateur distingue leur schema1 d’un reçu courant schema2 ;
leur validité historique ne qualifie pas les corrections de cette reprise.
Un nouveau sceau/promotion exige le code courant exact et les nouveaux cas.
Les80empreintes anciennes sont relevées avant la reprise dans
[reproduction-v2-before.json](reproduction-v2-before.json). Aucun compte,
réseau, modèle, paquet personnel ni configuration gérée n’est requis.

Reprise du30octobre2026 : le délai des appels du banc est désormais borné à60s
(4Mio par flux inchangés ; lanceur global600s). Le ciblé0979… avait passé3/3
en225,369s, mais le complet77868… passe13/15 en360,737s : garde native M15 et
knowledge local M1 dépassent15s. Ce budget de qualification Windows laisse de
la marge aux lectures froides et au démarrage des processus ; ce n'est ni une
promesse de latence produit ni un timeout métier. Aucun retry, refus de fichier
assoupli, nouveau moteur ou réseau n'est ajouté. Les anciens reçus gardent leur
code et leurs limites exécutés ; ils ne sont pas réécrits.
## Résultat final du30octobre2026

Le run [517afc…](runs/run-517afc048ef54c29806faaf1e4540feb/results.json)
passe **15/15 tests,230assertions,21observations et23appels gérés** sans skip,
en446,276s. Les558inputs observés sont identiques avant/après ; les15fixtures
sont retirées. La garde native et la garde Python refusent les14variantes de
code non admis avant lancement. Le plus long appel géré dure19,360s (knowledge),
puis18,250s (roster) : l'ancien plafond15s était trop court pour ces lectures.

Scellement et promotion explicites :73/73contrôles chacun ; manifeste
`19e6c9a7888c82c4428e4790307dfdfddd46ab9686dec14f55ea88e1bbf2fdb2`.
[selected-run.json](selected-run.json) désigne ce seul reçu courant. Les cinq
anciens runs restent historiques ; les cinq autres essais courants, ciblés ou
échoués, restent non scellés et ne prouvent pas une matrice complète.

Le [vérificateur parent](parent-verifier.mjs), lancé par `node` depuis la racine,
contrôle indépendamment la fermeture des sceaux, le code sélectionné courant,
129entrées sources, les80empreintes historiques, les deux archives et le bloc
approuvé inchangés. [Preuve parent](parent-verification.json).
La vérification Python en lecture seule et son contrôle avant/après sont dans
[parent-final-readonly.log](parent-final-readonly.log) et
[readonly-verification.json](readonly-verification.json).

La portée reste le profil candidat hors produit décrit ci-dessus. Relectures
finales et verdict de Build sont consignés dans le plan et le rapport parent ;
aucune UI ou invocation générale livrée ne se déduit de ces compteurs.