# Sources et voie exécutable — reprise2, 28 octobre 2026

Le [verrou](sources-lock.json), schema2, conserve les sept scripts gérés et
leurs empreintes, six copies identiques sous `.agents/skills/bmad/scripts`,
uv0.13.0, les734records du pin produit et558inputs produit/gérés/configurés.
Ces nombres désignent des périmètres distincts. Les scripts et le produit réels
restent en lecture seule ; aucun coffre/AppData n’est consulté.

Primitives réellement exécutées : `knowledge.collect/scan`,
`config_utils.merge_layers/load_central_config/load_customization`,
`roster.collect`, `tickets.load_folder/parse_frontmatter`. Les sources
`resolve_config`, `resolve_customization` et `setup_check` sont verrouillées et
inspectées, sans CLI ni hook exécuté. Les snapshots de données sont précontrôlés
dans le parent et à nouveau dans le worker ; aucun Python du projet analysé
n’est importé. `tickets.central_config`, `setup --status` et `render_skill`
restent exclus.

## Runtime fermé, voie unique courante

La source est le runtime fourni localement CPython3.12.14 hors projet. Son pin
produit `0f3ef35995160c8db3b4892d9bb3bd9ea0eba75634d4fc4505eef13e7ce56f92`
est défini dans `src/adapters/bmad/runtime.ts` ; il porte734fichiers sources et
binaires, pas les caches existants ni tous les formats importables. La reprise2
n’exécute donc plus cette base directement. Avant le PREMIER UV/Python,
`run.ps1` copie seulement chacun des734records vérifiés dans
`fixtures-runtime-owned/python`, vérifie l’empreinte de la copie et contrôle
exhaustivement son ensemble de fichiers/dossiers par `runtime-preflight.ps1`.
Les734records ne sont jamais recalculés depuis une nouvelle liste source.
Le binaire UV est SHA256
`2bfbe53d3cc95799e98fa08323b04844fc01d4f8c87dd5c00089e43f6554f162`.

Seuls ces734fichiers et leurs dossiers parents, plus un `Lib/site-packages`
**vide**, sont admis. Tout fichier/dossier supplémentaire est refusé, y compris
`.pyw`, `.pyc`, `__pycache__`, `.pth` ordinaire à la base ou ailleurs,
`python*._pth`, zip supplémentaire et startup dans Lib/DLLs. `pyvenv.cfg` est
refusé à la base ET au parent avant UV. Canonicité lexicale, liens/reparse et
hardlinks sont contrôlés. La même politique exhaustive est répétée dans
`runtime_guard.closed_manifest` avant chaque worker UV et avant chaque probe.
La source réelle peut conserver ses caches et son site-packages : ils ne sont
ni copiés ni exécutés ni modifiés. Aucun nouveau paquet n’est installé.

UV est appelé avec `run --offline --no-project --no-config --no-cache` et un
Python explicite. Les programmes du banc utilisent `-I -S -B`. L’inspection UV
elle-même est connue pour utiliser `-I -B`, sans `-S` : preuve statique du
[code amont versionné UV0.13.0](https://raw.githubusercontent.com/astral-sh/uv/0.13.0/crates/uv-python-interpreter/src/interpreter.rs),
query1172–1191, déjà obtenue lors de la reprise1. Sa phase site ne peut trouver
aucun hook dans la copie fermée. La neutralisation conditionnelle de distutils
de la reprise1 n’est plus la voie courante ; aucun `.pth` n’est admis.

Les sources primaires locales épinglées `Lib/importlib/_bootstrap_external.py`
1075–1135 montrent la lecture du bytecode avant le test d’écriture
`dont_write_bytecode`; `Lib/site.py`367–405 et523–551 montrent les sites Windows
base/site-packages et la recherche venv base/parent. `-B` ne promet pas une
absence de lecture des caches. M15 conserve deux caches réels ctypes/importlib
en **données** et éprouve leur ajout, les `.pyw`/legacy `.pyc`, startup Lib/DLLs,
`.pth` de base et les deux venv sur copies possédées, par les gardes native et
Python. Aucun de leurs payloads n’est exécuté ; les probes refusées n’atteignent
pas UV. Seule la copie exacte des734fichiers admis sert au probe UV positif.
Flags du programme final et absence de site y sont mesurés ; les flags internes
d’UV restent une preuve statique, sans instrumentation OS inventée.

Le processus enfant a un environnement filtré SYSTEMROOT/WINDIR/PATH, temp/cache
possédés ; aucun PYTHON*, VIRTUAL_ENV ou configuration personnelle n’est transmis.
Le runtime possédé et le cache sont supprimés en finally, y compris en erreur.
Ces contrôles valent aux points de préflight ; ils ne constituent pas une
sandbox contre un adversaire OS capable de modifier les octets après la garde.

## Collectes et reçus

`context-v2` collecte d’abord les trois couches centrales sûres. Le parseur TOML
strict et `config_utils.merge_layers` officiel opèrent **sur leurs octets
capturés**, puis output/initiative viennent de cette résolution. Une résolution
indépendante ne sert que d’assertion : divergence →
`CONFIG_RESOLUTION_MISMATCH`. `fresh_context` recapture ET résout ; M12 prouve
alpha résolu, configuration devenue beta, ancienne résolution refusée puis beta
fraîchement résolu, sans changement des skills. Le reçu conserve les couches
présentes et absentes, les octets, identités et empreintes. Relecture finale
des fichiers exploités et contrôle des couches ajoutées pendant la collecte.

Seuls les fichiers immédiats `<initiative>/<initiative>.md` exploités sont lus,
sans parcours récursif des livrables. Configurations et initiatives partagent
16Mio cumulés,1Mio/fichier et1024entrées. M11 refuse17fichiers de1Mio ; M8
invalide une initiative modifiée à skills identiques. Les collections de skills
restent indépendantes, avec profondeur12, UTF-8 strict et garde Windows du
handle avant consommation des octets. Relation module→skill→module réciproque,
prévalidation des personnalisations roster avant son repli masqué et preuves
TOML/feuille/plan/tracker avant jointure officielle restent exercées.

Chaque exécution écrit un nouveau `runs/run-<UUID>/`, avec code et verrou
exécutés. Scellement create-only et promotion explicite sont séparés de
`verify`, qui ne réécrit aucun reçu, sceau ou pin. Les anciennes preuves sont
vérifiables dans leur schema historique, explicitement **sans qualification
courante**. Un nouveau sceau/promotion exige le schema2 et le code courant exact.
Les archives iteration-0/1 et les cinq anciens runs ne sont jamais exécutés ou
modifiés ; leurs80empreintes initiales sont dans reproduction-v2-before.json.

Les chemins `snapshots/real-skills/` des résultats correspondent à
`.agents/skills/` réel, selon le verrou et la révision. Les autres racines
utilisateur/anciennes/futures sont des fixtures. Ces chemins retirés ne sont pas
des actions UI d’ouverture. Produit/géré/configuré :558inputs nommés et hachés,
ajouts/suppressions détectés aussi. Zéro réseau, OAuth, moteur, modèle,
configuration personnelle, installation ou dépendance produit requis.

Reprise du30octobre2026 : le délai des appels du banc est désormais borné à60s
(4Mio par flux inchangés ; lanceur global600s). Le ciblé0979… avait passé3/3
en225,369s, mais le complet77868… passe13/15 en360,737s : garde native M15 et
knowledge local M1 dépassent15s. Ce budget de qualification Windows laisse de
la marge aux lectures froides et au démarrage des processus ; ce n'est ni une
promesse de latence produit ni un timeout métier. Aucun retry, refus de fichier
assoupli, nouveau moteur ou réseau n'est ajouté. Les anciens reçus gardent leur
code et leurs limites exécutés ; ils ne sont pas réécrits.