# Vérification parent — story 2.1

30 octobre 2026. Baseline : `ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb`.
Qualification isolée du profil BMad local ; aucun changement du produit.

## Résultats indépendamment contrôlés

Le run sélectionné est `run-0157a52bd7b145249da9a2e937d80371` : 15/15 tests,
270 assertions, 23 observations, zéro erreur/échec/skip. Durée du reçu :
440,938 s. Les 28 appels observés comprennent 23 appels gérés réussis,
deux refus attendus avec provenance et trois probes. Maximum : 13,828 s
et 157 965 octets, sous les bornes expérimentales 60 s/4 Mio.

Les quinze lignes M1–M15 ont été rapprochées des tests effectivement passés
et de leurs preuves. M10 exerce réellement hardlinks, jonctions Windows et
remplacement d'ancêtre. M7 refuse le TOML de roster avant son repli masqué ;
M8/M12 calculent le contexte depuis les mêmes octets capturés et invalident
une ancienne résolution. M11 borne séparément les initiatives ; M13 conserve
TOML/feuille/plan/tracker, avec LF, CRLF, BOM+LF et BOM+CRLF.

M15 conserve la copie fermée de 734 fichiers avant le premier UV. Les deux
gardes refusent 14 variantes runtime avant lancement. Les sept modules du banc
sont capturés depuis leurs sources épinglées puis compilés en mémoire : aucun
import depuis HERE ou cache du banc. Huit variantes d'import sont éprouvées,
une source modifiée est refusée. Entrée, workers et refus conservent la même
provenance. La frontière d'audit n'est pas une sandbox contre un adversaire OS.

La supervision native commune possède ses trois racines avant enfant. Le run
`run-3e81ef4bdc28483dad0a5d2fde8c9a8e` constate le marqueur à 5,981 s,
puis coupe après 4 s : timeout attendu, aucun results.json, trois racines
retirées et lecture 2/2 non qualifiée. M15 vérifie aussi nouvel enfant exit0,
lancement impossible, plafond de sortie, refus hors possession et non-suivi
d'une jonction. Les échecs antérieurs restent consultables avec leurs limites.

## Preuves et conservation

Le scellement et la promotion distincte passent chacun 95/95 ; la vérification
en lecture seule passe 94/94. Les logs natifs existent sous `logs/`, sans
reconstruction de ceux historiquement absents. Manifeste courant :
`cfdd5470db4e319c05d1ac35add9e5bcb26724067b0ffe38ededc5ad7d92006c`.
Il couvre 25 artifacts ; avec lui, le reçu contient 26 fichiers.

Le [vérificateur parent](parent-verifier.mjs), exécuté séparément, contrôle les
18 runs (complets, historiques ou incomplets), les fermetures de fichiers,
les empreintes, les résultats, la provenance et le bloc figé. Il passe :
[sortie réellement reçue](parent-verification.json). 558 inputs sont inchangés
selon le banc ; les 129 sources indépendantes, 164 anciens fichiers et trois
archives sont aussi vérifiés identiques. Aucune racine de fixture résiduelle.

Le parent a comparé les cartes avant/après du worker aux octets présents :
26 fichiers du reçu courant et 20 du ciblé historique schema3 sont identiques.
La sortie native 94/94 est lue et hachée, sans prétendre une nouvelle exécution :
[comparaison indépendante](readonly-verification.json). L'ancienne comparaison
schema2 reste [historique](readonly-verification-v2.json).

Bloc approuvé SHA256 :
`04d5977b155af629da97dddb2fdfd6fcd85688948de133cc701c6d389037db18`.
Les attributs Git préservent les octets des preuves et du seul plan.

## Reproduction et portée

Depuis la racine, PowerShell 7 :

```powershell
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action run
# Nouvelle exécution neuve ; scellement et sélection explicites ensuite.
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action verify -RunId 'run-0157a52bd7b145249da9a2e937d80371'
node '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/parent-verifier.mjs'
```

Un refus NTFS est un échec, jamais un skip vert. Runtime, UV, sources et limites
sont épinglés dans sources-lock.json et documentés dans [sources.md](sources.md).
Le budget du banc ne définit ni une latence UI ni une durée métier par US.

Les revues Quick et frontières indépendantes fraîches restent à rendre à ce
point. Les tours et corrections antérieurs sont conservés dans le plan.
Installation observée exacte : 6.13.0-next, trois modules, 27 descripteurs,
trois aides chargées, 43 topics et deux migrations en références. Diagnostic
partiel connu : bmad-retrospective absente ; aucune réparation implicite.

Les contrats documentaires sont proposés au cœur pour Sally 2.17 puis le
tracer 2.2. G2 intégré reste à vérifier en 2.16. Aucun catalogue général,
aide native, accord visuel humain ou autre epic déclaré livré. Mary/Forge,
SIWC, cache réseau et application installée inchangés. Suite produit, build
et installateur non relancés : leurs sources n'ont pas changé. Aucun compte,
AppData, fournisseur, réseau, modèle ou installation personnelle requis.
