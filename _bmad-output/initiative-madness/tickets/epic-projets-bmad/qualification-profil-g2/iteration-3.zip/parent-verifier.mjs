import {readFile,readdir,lstat} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {join,resolve,relative,isAbsolute} from 'node:path'
const root='_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2'
const ok=(v,m)=>{if(!v)throw new Error(m)}
const hash=b=>createHash('sha256').update(b).digest('hex')
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b)
const read=p=>readFile(p,'utf8').then(v=>JSON.parse(v.replace(/^\uFEFF/,'')))
const optional=async p=>{try{return await read(p)}catch(e){if(e.code==='ENOENT')return null;throw e}}
const code2=['prototype.py','fixtures.py','scenarios.py','runtime_guard.py','evidence.py','verify.py','run.ps1','runtime-preflight.ps1','preflight-probe.ps1','sources-lock.json']
const code1=code2.filter(n=>!['runtime-preflight.ps1','preflight-probe.ps1'].includes(n))
const bench3=['prototype.py','fixtures.py','scenarios.py','runtime_guard.py','evidence.py','verify.py','source_bootstrap.py','run.ps1','runtime-preflight.ps1','preflight-probe.ps1','supervision.ps1','supervision-probe.ps1']
const code3=[...bench3,'sources-lock.json']
const dataBase=['results.json','inventory-local.json','context-local.json','tickets-local.json','tickets-conflict.json','scenarios.log','calls.log']
const data3=[...dataBase,'execution.json','launcher.stdout.log','launcher.stderr.log','supervision-probe.stdout.log','supervision-probe.stderr.log']
const recordHash=async path=>{const st=await lstat(path);ok(st.isFile()&&!st.isSymbolicLink()&&st.nlink===1,'Non-regular evidence '+path);return hash(await readFile(path))}
const lock=await read(join(root,'sources-lock.json'))
ok(lock.schema===3&&lock.runtime.policy==='closed-copy-v2','Current schema3 runtime policy')
ok(same(Object.keys(lock.bench).sort(),bench3.slice().sort()),'Current exact admitted bench set')
for(const name of bench3)ok(await recordHash(join(root,name))===lock.bench[name],'Current bench pin '+name)
const selected=await read(join(root,'selected-run.json'))
const runSummary=[]
let selectedResults=null
for(const item of await readdir(join(root,'runs'),{withFileTypes:true})){
 ok(item.isDirectory()&&/^run-[a-f0-9]{32}$/.test(item.name),'Unexpected run folder '+item.name)
 const dir=join(root,'runs',item.name),info=await lstat(dir)
 ok(!info.isSymbolicLink(),'Reparse run '+item.name)
 const hashes={}
 for(const name of await readdir(dir)){
  ok(/^[a-zA-Z0-9_.-]+$/.test(name),'Unexpected artifact name '+name)
  hashes[name]=await recordHash(join(dir,name))
 }
 const runLock=await optional(join(dir,'sources-lock.json'))
 const result=await optional(join(dir,'results.json'))
 const execution=await optional(join(dir,'execution.json'))
 const schema=runLock?.schema??execution?.schema??1
 const manifest=await optional(join(dir,'evidence-manifest.json'))
 const full=result?.tests?.run===15&&result.tests.passed===15&&result.tests.errors===0&&result.tests.failures===0&&result.tests.skipped===0
 let classification=execution&&execution.outcome!=='completed'?'incomplete':result?'unsealed-tested':'incomplete'
 if(runLock?.bench){
  ok(schema===3&&same(Object.keys(runLock.bench).sort(),bench3.slice().sort()),'Recorded bench set '+item.name)
  for(const [name,expected] of Object.entries(runLock.bench))if(name in hashes)ok(hashes[name]===expected,'Changed recorded bench '+item.name+'/'+name)
 }
 if(result){
  const before=result.preservation.before,after=result.preservation.after
  ok(Object.keys(before).length===558&&Object.keys(after).length===558&&Object.keys(runLock.preservation_before).length===558,'Input closure '+item.name)
  ok(Object.entries(before).every(([p,h])=>h===after[p]&&h===runLock.preservation_before[p]),'Source conservation '+item.name)
  ok(result.cleanup.length===result.tests.run&&result.cleanup.every(c=>c.removed),'Case cleanup '+item.name)
 }
 if(manifest){
  const code=schema===1?code1:schema===2?code2:schema===3?code3:null
  ok(code,'Unsupported sealed schema '+schema)
  const names=[...code,...(schema===3?data3:dataBase)].sort()
  ok(same(Object.keys(manifest.sha256).sort(),names),'Closed evidence set '+item.name)
  ok(Object.entries(manifest.sha256).every(([n,h])=>hashes[n]===h),'Manifest hashes '+item.name)
  ok(full&&result.matrix.length===15&&result.matrix.every((m,i)=>m.id==='M'+(i+1)&&m.passed&&m.assertions>0),'Full passed matrix '+item.name)
  const log=await readFile(join(dir,'scenarios.log'),'utf8')
  for(let i=1;i<=15;i++)ok(log.split(/\r?\n/).some(line=>line.startsWith('test_M'+i+'_')&&line.endsWith(' ... ok')),'Executed M'+i+' '+item.name)
  classification='historical-sealed'
 }
 if(item.name===selected.run){
  ok(schema===3&&manifest&&full,'Selected current full sealed run')
  ok(selected.manifest_sha256===hashes['evidence-manifest.json'],'Selected manifest reference')
  for(const name of code3)ok(await recordHash(join(root,name))===hashes[name],'Selected code is current '+name)
  ok(execution?.schema===3&&execution.outcome==='completed'&&execution.exit===0&&execution.results_present,'Selected terminal launcher')
  ok(execution.cleanup.length>0&&execution.cleanup.every(c=>c.removed),'Selected launcher cleanup')
  const closure=Object.fromEntries(Object.entries(runLock.bench).filter(([n])=>n.endsWith('.py')).map(([n,h])=>[n.slice(0,-3),h]))
  const closureMatches=value=>value&&Object.keys(value).length===Object.keys(closure).length&&Object.entries(closure).every(([n,h])=>value[n]===h)
  ok(result.bench_execution?.policy==='captured-source-only-v3'&&closureMatches(result.bench_execution.sha256)&&result.bench_execution.bootstrap_sha256===runLock.bench['source_bootstrap.py'],'Entry actual source closure')
  const calls=(await readFile(join(dir,'calls.log'),'utf8')).split(/\r?\n/).filter(Boolean).map(JSON.parse)
  ok(calls.length>0&&calls.every(c=>c.duration_ms<60000&&c.stdout_bytes<=4194304&&c.stderr_bytes<=4194304),'Bounded actual calls')
  for(const c of calls.filter(c=>!['runtime-inspection-probe','bench-source-probe'].includes(c.op)))ok(closureMatches(c.bench_execution?.sha256)&&c.bench_execution.bootstrap_sha256===runLock.bench['source_bootstrap.py'],'Worker source closure '+c.op)
  const conflict=await read(join(dir,'tickets-conflict.json'))
  ok(conflict.sources.leaves[0].fields.status==='done'&&conflict.sources.plans[1].fields.status==='in-progress'&&conflict.encoding_variants.length===3,'Windows independent ticket fields')
  for(const v of conflict.encoding_variants){
   ok(v.proof.sources.leaves[0].fields.status==='done'&&v.proof.sources.plans[1].fields.status==='in-progress','Windows variant fields')
   for(const s of v.proof.sources.files)ok(hash(Buffer.from(s.content,'utf8'))===s.sha256,'Windows raw bytes')
  }
  const imports=result.observations.find(o=>o.case==='M15'&&o.data.source_only)?.data
  ok(imports?.ignored_variants.length===8&&imports.changed_source_refused&&closureMatches(imports.sha256),'Adversarial source-only harness')
  const stop=result.observations.find(o=>o.case==='M15'&&o.data.forced)?.data
  ok(stop?.forced.outcome==='timeout'&&stop.forced.marker_observed&&!stop.forced.results_present,'Real forced stop after marker')
  ok(stop.failed_start.outcome==='start-failed'&&stop.next.outcome==='completed'&&stop.next.exit===0,'Start failure and next run')
  for(const name of ['forced','next','failed_start'])ok(stop[name].cleanup.every(c=>c.removed),'Owned probe cleanup '+name)
  ok((await readFile(join(dir,'launcher.stdout.log'),'utf8')).includes('NEW_RUN: '+item.name),'Native stdout actually captured')
  selectedResults={run:item.name,tests:result.tests,assertions:result.matrix.reduce((n,m)=>n+m.assertions,0),observations:result.observations.length,calls:calls.length,duration_ms:result.duration_ms,manifest_sha256:hashes['evidence-manifest.json']}
  classification='current-selected'
 }
 runSummary.push({run:item.name,schema,classification,sealed:!!manifest,tests:result?.tests??null,files:Object.keys(hashes).length,execution_outcome:execution?.outcome??null})
}
ok(selectedResults,'Selected run exists')
const historic=await read(join(root,'reproduction-v3-before.json'))
for(const [name,expected] of Object.entries(historic)){
 ok(/^runs[/\\]run-[a-f0-9]{32}[/\\][a-zA-Z0-9_.-]+$/.test(name),'Historical path')
 ok(await recordHash(join(root,...name.split(/[/\\]/)))===expected,'Historical receipt changed '+name)
}
ok(Object.keys(historic).length===164,'Historical164 closure')
for(const [name,expected] of [['iteration-0.zip','109c937e26b8dd2e3b3dfedf0b0abdae814be089ac36a486f8553cda53b223be'],['iteration-1.zip','dd86933f293a98587dc6585d11b46c76029eb283a40727bdc8a94a5779bb31a2'],['iteration-2.zip','af21c3af09a5dc5a3ebb49842a4a4ed7096eb1fb179446ca2ed5e8f3df01997e']])ok(await recordHash(join(root,name))===expected,'Archive changed '+name)
const inputs=await read(join(root,'parent-inputs.json'))
ok(inputs.baseline==='ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb'&&inputs.inputs.length===129,'Independent input closure')
for(const item of inputs.inputs){
 const delta=relative(process.cwd(),resolve(item.path))
 ok(delta&&!delta.startsWith('..')&&!isAbsolute(delta),'Independent input outside repository')
 let value=null
 try{value=await recordHash(item.path)}catch(e){if(e.code!=='ENOENT')throw e}
 ok(value===item.sha256,'Source changed '+item.path)
}
const plan=await readFile(join(root,'../tickets/spike-qualifier-le-profil-bmad-existant-et-les-contrats-de-guidage-plan.md'),'utf8')
const frozenSha256=hash(plan.match(/<frozen-after-approval[\s\S]*?<\/frozen-after-approval>/)[0])
ok(frozenSha256==='04d5977b155af629da97dddb2fdfd6fcd85688948de133cc701c6d389037db18','Approved intent changed')
ok(!(await readdir(root)).some(n=>n.startsWith('fixtures-')),'Owned transient remains')
console.log(JSON.stringify({status:'passed',baseline:inputs.baseline,frozenSha256,inputCount:129,historicalFilesUnchanged:164,archivesUnchanged:3,selected:selectedResults,runCount:runSummary.length,runs:runSummary}))