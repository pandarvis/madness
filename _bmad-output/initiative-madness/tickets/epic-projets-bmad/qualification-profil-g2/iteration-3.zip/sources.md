# Sources et voie exécutable — reprise3, 30 octobre 2026

Le [verrou](sources-lock.json), schema3, conserve les sept scripts gérés et
leurs empreintes, six copies identiques sous `.agents/skills/bmad/scripts`,
uv0.13.0, les734records du pin produit et558inputs produit/gérés/configurés.
Ces nombres désignent des périmètres distincts. Les scripts et le produit réels
restent en lecture seule ; aucun coffre/AppData n’est consulté.

Primitives réellement exécutées : `knowledge.collect/scan`,
`config_utils.merge_layers/load_central_config/load_customization`,
`roster.collect`, `tickets.load_folder/parse_frontmatter`. Les sources
`resolve_config`, `resolve_customization` et `setup_check` sont verrouillées et
inspectées, sans CLI ni hook exécuté. Les snapshots de données sont précontrôlés
dans le parent et à nouveau dans le worker ; aucun Python du projet analysé
n’est importé. `tickets.central_config`, `setup --status` et `render_skill`
restent exclus.

## Runtime fermé, voie unique courante

La source est le runtime fourni localement CPython3.12.14 hors projet. Son pin
produit `0f3ef35995160c8db3b4892d9bb3bd9ea0eba75634d4fc4505eef13e7ce56f92`
est défini dans `src/adapters/bmad/runtime.ts` ; il porte734fichiers sources et
binaires, pas les caches existants ni tous les formats importables. La reprise2
n’exécute donc plus cette base directement. Avant le PREMIER UV/Python,
`run.ps1` copie seulement chacun des734records vérifiés dans
`fixtures-runtime-owned/python`, vérifie l’empreinte de la copie et contrôle
exhaustivement son ensemble de fichiers/dossiers par `runtime-preflight.ps1`.
Les734records ne sont jamais recalculés depuis une nouvelle liste source.
Le binaire UV est SHA256
`2bfbe53d3cc95799e98fa08323b04844fc01d4f8c87dd5c00089e43f6554f162`.

Seuls ces734fichiers et leurs dossiers parents, plus un `Lib/site-packages`
**vide**, sont admis. Tout fichier/dossier supplémentaire est refusé, y compris
`.pyw`, `.pyc`, `__pycache__`, `.pth` ordinaire à la base ou ailleurs,
`python*._pth`, zip supplémentaire et startup dans Lib/DLLs. `pyvenv.cfg` est
refusé à la base ET au parent avant UV. Canonicité lexicale, liens/reparse et
hardlinks sont contrôlés. La même politique exhaustive est répétée dans
`runtime_guard.closed_manifest` avant chaque worker UV et avant chaque probe.
La source réelle peut conserver ses caches et son site-packages : ils ne sont
ni copiés ni exécutés ni modifiés. Aucun nouveau paquet n’est installé.

UV est appelé avec `run --offline --no-project --no-config --no-cache` et un
Python explicite. Les programmes du banc utilisent `-I -S -B`. L’inspection UV
elle-même est connue pour utiliser `-I -B`, sans `-S` : preuve statique du
[code amont versionné UV0.13.0](https://raw.githubusercontent.com/astral-sh/uv/0.13.0/crates/uv-python-interpreter/src/interpreter.rs),
query1172–1191, déjà obtenue lors de la reprise1. Sa phase site ne peut trouver
aucun hook dans la copie fermée. La neutralisation conditionnelle de distutils
de la reprise1 n’est plus la voie courante ; aucun `.pth` n’est admis.

Les sources primaires locales épinglées `Lib/importlib/_bootstrap_external.py`
1075–1135 montrent la lecture du bytecode avant le test d’écriture
`dont_write_bytecode`; `Lib/site.py`367–405 et523–551 montrent les sites Windows
base/site-packages et la recherche venv base/parent. `-B` ne promet pas une
absence de lecture des caches. M15 conserve deux caches réels ctypes/importlib
en **données** et éprouve leur ajout, les `.pyw`/legacy `.pyc`, startup Lib/DLLs,
`.pth` de base et les deux venv sur copies possédées, par les gardes native et
Python. Aucun de leurs payloads n’est exécuté ; les probes refusées n’atteignent
pas UV. Seule la copie exacte des734fichiers admis sert au probe UV positif.
Flags du programme final et absence de site y sont mesurés ; les flags internes
d’UV restent une preuve statique, sans instrumentation OS inventée.

Le processus enfant a un environnement filtré SYSTEMROOT/WINDIR/PATH, temp/cache
possédés ; aucun PYTHON*, VIRTUAL_ENV ou configuration personnelle n’est transmis.
Le runtime possédé et le cache sont supprimés en finally, y compris en erreur.
Ces contrôles valent aux points de préflight ; ils ne constituent pas une
sandbox contre un adversaire OS capable de modifier les octets après la garde.

## Collectes et reçus

`context-v2` collecte d’abord les trois couches centrales sûres. Le parseur TOML
strict et `config_utils.merge_layers` officiel opèrent **sur leurs octets
capturés**, puis output/initiative viennent de cette résolution. Une résolution
indépendante ne sert que d’assertion : divergence →
`CONFIG_RESOLUTION_MISMATCH`. `fresh_context` recapture ET résout ; M12 prouve
alpha résolu, configuration devenue beta, ancienne résolution refusée puis beta
fraîchement résolu, sans changement des skills. Le reçu conserve les couches
présentes et absentes, les octets, identités et empreintes. Relecture finale
des fichiers exploités et contrôle des couches ajoutées pendant la collecte.

Seuls les fichiers immédiats `<initiative>/<initiative>.md` exploités sont lus,
sans parcours récursif des livrables. Configurations et initiatives partagent
16Mio cumulés,1Mio/fichier et1024entrées. M11 refuse17fichiers de1Mio ; M8
invalide une initiative modifiée à skills identiques. Les collections de skills
restent indépendantes, avec profondeur12, UTF-8 strict et garde Windows du
handle avant consommation des octets. Relation module→skill→module réciproque,
prévalidation des personnalisations roster avant son repli masqué et preuves
TOML/feuille/plan/tracker avant jointure officielle restent exercées.

Chaque exécution écrit un nouveau `runs/run-<UUID>/`, avec code et verrou
exécutés. Scellement create-only et promotion explicite sont séparés de
`verify`, qui ne réécrit aucun reçu, sceau ou pin. Les anciennes preuves sont
vérifiables dans leur schema historique, explicitement **sans qualification
courante**. Un nouveau sceau/promotion exige le schema3 et le code courant exact.
Les archives iteration-0/1/2 et les11anciens runs ne sont jamais exécutés ou
modifiés ; leurs164empreintes initiales sont dans reproduction-v3-before.json.

Les chemins `snapshots/real-skills/` des résultats correspondent à
`.agents/skills/` réel, selon le verrou et la révision. Les autres racines
utilisateur/anciennes/futures sont des fixtures. Ces chemins retirés ne sont pas
des actions UI d’ouverture. Produit/géré/configuré :558inputs nommés et hachés,
ajouts/suppressions détectés aussi. Zéro réseau, OAuth, moteur, modèle,
configuration personnelle, installation ou dépendance produit requis.

Reprise du30octobre2026 : le délai des appels du banc est désormais borné à60s
(4Mio par flux inchangés ; lanceur global600s). Le ciblé0979… avait passé3/3
en225,369s, mais le complet77868… passe13/15 en360,737s : garde native M15 et
knowledge local M1 dépassent15s. Ce budget de qualification Windows laisse de
la marge aux lectures froides et au démarrage des processus ; ce n'est ni une
promesse de latence produit ni un timeout métier. Aucun retry, refus de fichier
assoupli, nouveau moteur ou réseau n'est ajouté. Les anciens reçus gardent leur
code et leurs limites exécutés ; ils ne sont pas réécrits.
## Imports du banc et supervision — politique schema3 courante

Le verrou bench épingle douze fichiers exécutables : sept sources Python et
cinq scripts PowerShell, dont le collecteur C# embarqué dans supervision.ps1.
Le lanceur vérifie ces octets avant ses aides et le premier UV, puis conserve
leurs copies dans le run avant de démarrer l'enfant.

Le bootstrap est passé comme texte -c vérifié. Il capture les seuls .py nommés
par le verrou, contrôle chemins/liens/tailles/stabilité/empreintes puis garde
leurs octets en mémoire. Un MetaPathFinder/Loader compile ces sources admises,
sans SourceFileLoader, cache ou recherche dans HERE. Le sys.path reste celui
de CPython fermé sous -I -S -B. Les scripts gérés sont chargés par leurs octets
épinglés. Entrée et workers emploient cette même voie ; bench_execution conserve
les hashes capturés, les modules compilés et le hash du véritable texte -c.
M15 éprouve huit formes de cache/extension/paquet sur copie possédée : elles
restent données non consultées. Une source admise changée est refusée avant
import, sans jamais exécuter sa charge. Les14variantes runtime restent testées.

Le parent alloue avant enfant un run neuf, sa racine unique de fixtures, et
execution.json. Ce reçu atomique conserve issue/PID/possession/nettoyage ;
timeout, lancement impossible et échec de capture/nettoyage restent explicites,
même sans results.json. Le vérificateur sait lire ces seules preuves disponibles
et refuse leur scellement/promotion. Les schema1/2 restent strictement
historiques et vérifiables sans nouvelle qualification.

La même supervision native est utilisée dans le lanceur et M15 : arrêt réel
après constat d'un fichier créé par l'enfant, nettoyage parent sans dépendre
des callbacks unittest, lancement impossible, sortie excessive et nouvel enfant
réussi. Budget de coupure4s après marqueur, handshake froid séparé30s maximum et probes de reprise/sortie10s ; aucun600s attendu. Un collecteur natif borne chaque
pipe à4Mio ; launcher.stdout.log et launcher.stderr.log gardent les octets
réellement reçus. Write-Output permet aussi une capture pipeline. Aucun journal
parent-final-*.log absent du schema2 n'est reconstruit rétroactivement.

Le teardown vérifie la possession et retire une entrée reparse seule ; il ne
suit jamais une jonction par suppression récursive. M15 vérifie le refus hors
possession et conserve un témoin derrière une jonction. Les seules nouvelles
opérations de lecture écrivent leurs propres journaux sous logs/, jamais le
run qu'elles relisent. Les11runs/164fichiers antérieurs et trois archives sont
conservés selon reproduction-v3-before.json.

parse_text normalise uniquement la vue utf8-sig/newlines universelles, comme
le read_text officiel. Raw/content/hashes restent exacts. M13 éprouve LF, CRLF,
BOM+LF et BOM+CRLF avec statuts feuille/plan contradictoires.

Recette PowerShell7 depuis la racine :
& '_bmad-output\initiative-madness\tickets\epic-projets-bmad\qualification-profil-g2\run.ps1' -Action run
Puis -Action seal -RunId <id>, -Action verify -RunId <id> et
-Action promote -RunId <id>, trois opérations distinctes. NEW_RUN et
LAUNCH_RECEIPT donnent le dossier des journaux. -Action windows-proof cible
M13 ; -Action probe cible M8/M12/M15. -Action interrupt-proof exerce le lanceur
exact avec délai4s après son marqueur (handshake maximum30s) : son exit1/timeout est attendu et jamais qualifié comme
matrice complète. Sa lecture -Action verify doit conserver current_qualification
false et constater absence de results, marqueur enfant et nettoyage.
## Ajustements Windows mesurés et échecs conservés

La première matrice schema3 cc0e94afffa344e0bf62a6e6a98f49df conserve13/15 :
sortie OEM du probe natif (byte0x82) et MAX_PATH pendant le snapshot d'une skill
profonde. La sortie UTF-8 est désormais imposée dans le seul processus du probe ;
les sous-dossiers cN restent sous la racine run-UUID possédée et évitent cet
allongement artificiel. Les bornes de lecture et les refus restent identiques.

La matrice7b71fa6c366f4225a8e4a8adb99298b9 conserve14/15 : sous cette installation
PowerShell comme outil .NET, Get-Process($PID).Path désigne dotnet.exe. Les
enfants de test ne doivent pas recevoir dotnet --NoProfile. Le probe sélectionne
le premier pwsh.exe concret de Get-Command, comme la découverte par PATH du
parent ; ses stderr enfants et son hôte sont dans le JSON conservé. Le ciblé
logs/native-focused-0b3ba15e94b340bc830e261d5ec5e096 passe l'arrêt après marqueur,
la reprise exit0, le lancement impossible et le plafond de sortie.

09ee3cc7a04f420aa0f80d0404885cf2 garde l'ancienne erreur du collecteur et sa
récupération explicite des seuls espaces possédés ; aucune réussite de teardown
initial n'est reconstruite. b29cc3cbb9644a95a183e0542c9d626c garde la coupure
trop précoce avant marqueur ; 3e81ef4bdc28483dad0a5d2fde8c9a8e prouve ensuite le
vrai marqueur suivi du délai4s et du nettoyage. Sa lecture reste non qualifiée.

Les refus attendus des workers conservent désormais la même provenance
capturée que leurs réponses réussies. Un ancien schema3 dont bench diffère
du code courant est historique : même15/15 ne suffirait pas à le promouvoir
sous la nouvelle politique. Les essais partiels restent lisibles avec leurs
seules preuves disponibles. Aucun ancien code n'est réexécuté pour les lire.