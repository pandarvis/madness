# Vérification parent — story 2.1

30 octobre 2026. Baseline `ebe2bb3c5279fcb95bd48e0a0da917bce04dddfb`.
Qualification isolée du profil BMad ; aucun changement du produit.

## Résultat contrôlé

Le candidat sélectionné est `run-16822ad1c1f04c459a9c8bf974990770` :
**15/15 scénarios, 415 assertions, 27 observations, zéro échec/erreur/skip**.
Le reçu mesure 406,062 s (unittest 404,018 s). Les 28 appels observés comprennent
23 appels gérés réussis, deux refus attendus avec provenance et trois probes.
Maximum : 10,891 s et 179 105 octets, sous les bornes expérimentales 60 s/4 Mio.

Le parent a rapproché les quinze lignes M1–M15 des tests réellement passés et
de leurs preuves. M10 exerce hardlinks, jonctions Windows et remplacement
d'ancêtre. M7 refuse les configurations invalides avant repli masqué et
compare LF/CRLF/BOM/CR isolé au chargeur TOML binaire officiel. M8/M12 résolvent
les mêmes octets capturés et invalident l'ancien contexte ; M11 borne les
initiatives ; M13 conserve les champs et octets TOML/feuille/plan/tracker.

M15 contrôle la copie runtime fermée de 734 fichiers avant le premier UV et
14 variantes refusées. Entrée et workers compilent les sept modules capturés,
sans import depuis HERE/cache ; huit variantes et une source changée sont
éprouvées. La provenance est conservée aussi dans les refus.

Les lecteurs historiques et incomplets utilisent la même capture fermée avant
exploitation : 32 clés non admises, fichiers témoins extérieurs, hardlinks,
jonctions, tailles individuelles et cumulées. Les deux destinations de reçu
et le pointeur de sélection refusent leurs liens préexistants avant écriture.
Le vrai main --promote est exercé ; le témoin extérieur reste intact et aucun
reçu de promotion n'est créé lors du refus. La promotion régulière finale passe.

La supervision par Job Object précède ResumeThread ; arrêt et vidange sont
bornés. Dans le full courant, le parent sort0 avec un enfant30s tenant les pipes :
job2→0, enfant identifié absent, retour2,833s/vidange93ms. Reprise completed/0,
timeout, start-failed, overflow et nettoyage sont vérifiés. Le probe utilise le
vrai PowerShell7.5.4 de PSHOME, SHA256
`9660387054b1387f5ab7e907a61560674c762559f91279a50484240bb3659d53`,
également comparé par le parent au binaire actuellement présent.

## Sceaux, lecture et conservation

Scellement **103/103**, lecture seule **102/102**, promotion distincte **103/103**.
Manifeste `98055ef2e89c2b3f8f65bf57a617ec124da04c900e7cf37446ac70fa176cb1fb` :
25 payloads et le manifeste, soit 26 fichiers du reçu.
Les journaux natifs existent ; aucun journal ancien absent n'a été recréé.

Le [vérificateur parent](parent-verifier.mjs), exécuté séparément et en lecture
seule, passe sur les **25 runs**, leurs ensembles fermés, empreintes, résultats,
provenance, bornes et sélection : [sortie réellement reçue](parent-verification.json).
558 inputs sont conservés par le banc ; les **129 sources indépendantes**,
**304 fichiers antérieurs** et **quatre archives** sont aussi vérifiés identiques.
Aucune racine de fixture ne reste après les lanceurs.

Le parent a comparé les 78 cartes avant/après du worker aux octets présents,
pour le courant, le premier v4 et le témoin schema3 ; les trois sorties natives
103/102/103 sont lues et hachées sans prétendre les avoir rejouées :
[comparaison indépendante](readonly-verification.json).

L'interruption `run-b48b4d415b1744239c77fa8eac3c20ec` reste historique : marqueur
après4,157s, timeout4s, job3→0, vidange85ms, trois racines retirées, sans
results.json et lecture2/2 non qualifiée. Le parent a comparé les octets de
supervision.ps1 : identiques au courant. Le probe et le vérificateur ont évolué
ensuite ; les cas d'arrêt de cette même supervision passent dans le full actuel.

Les essais précédents restent conservés, notamment 6501…14/15 : le shim de
PowerShell laissait un descendant transitoire et M15 s'arrêtait AVANT le contrôle
du pointeur. Ce contrôle n'est attribué qu'au ciblé et au full1682… corrigé.
Une sonde de symlink fichier exigeait un privilège Windows absent : aucun lien
créé ni skip vert ; cette variante native reste non éprouvée. Les vraies
jonctions/hardlinks ne lui sont pas substitués. Aucune sandbox OS universelle
ni protection contre un adversaire modifiant les octets après préflight promise.

Bloc figé SHA256
`04d5977b155af629da97dddb2fdfd6fcd85688948de133cc701c6d389037db18`.
Les attributs Git préservent les octets des preuves et du seul plan.

## Reproduction et portée

Depuis la racine, PowerShell7 :

```powershell
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action run
# Nouveau run ; scellement et promotion ensuite, chacun explicitement.
& '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/run.ps1' -Action verify -RunId 'run-16822ad1c1f04c459a9c8bf974990770'
node '_bmad-output/initiative-madness/tickets/epic-projets-bmad/qualification-profil-g2/parent-verifier.mjs'
```

Un refus NTFS requis est un échec, jamais un skip vert. Sources, runtimes,
recettes et limites sont dans [sources.md](sources.md). Les budgets du banc
ne définissent ni latence UI ni durée métier par US.

Les revues Quick et frontières indépendantes fraîches restent à rendre à ce
point ; leurs tours antérieurs sont conservés dans le plan. L'installation
observée est exactement6.13.0-next : trois modules,27descripteurs,trois aides
chargées,43topics,deux migrations référencées et diagnostic partiel connu
(bmad-retrospective absente), sans réparation implicite.

Les [contrats documentaires](profil-g2.md) sont prêts pour le cœur, Sally2.17
puis le tracer2.2. G2 intégré sera vérifié en2.16 ; aucun catalogue/aide native
UI ou lancement général livré ici. Mary/Forge, SIWC, cache réseau et application
installée sont inchangés. Suite produit/build/installateur non relancés puisque
leurs sources sont conservées. Aucun compte, AppData, fournisseur, réseau,
modèle, privilège Windows nouveau ou installation personnelle requis.
